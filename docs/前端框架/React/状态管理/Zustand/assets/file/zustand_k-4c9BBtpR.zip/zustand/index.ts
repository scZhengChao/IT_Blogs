import create from 'zustand'
import a from './model/a'
import b from './model/b'
import log from './middleware/log'
import presistFn from './middleware/presist'

function compose(...funcs) {
    if (funcs.length === 0) {
        return arg => arg
    }
    if (funcs.length === 1) {
        return funcs[0]
    }
    return funcs.reduce((a, b) =>(...args) => a(b(...args)))
}

const store = (...options) => ({
    ...a(...options),
    ...b(...options)
})
const useBearStore = compose(create,presistFn,log)(store)

// 1. 创建Store
// const useDogStore = create(() => ({ paw: true, snout: true, fur: true }))

// 2. react 环境外直接拿值
// const paw = useDogStore.getState().paw

// 3. 提供外部事件订阅
// const unsub1 = useDogStore.subscribe(console.log)

// 4. react 世界外更新值
// useDogStore.setState({ paw: false })


export default useBearStore