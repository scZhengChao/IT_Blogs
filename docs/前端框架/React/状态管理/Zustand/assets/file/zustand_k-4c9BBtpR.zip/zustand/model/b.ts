const createBearSlice = (set,get)=>({
    removeAllBears: () => set({ bears: 0 }),
    createNewDesignSystem: async () => {
        const {  toggleLoading } = get();

        toggleLoading();
        const res = await fetch('https://api.vvhan.com/api/joke').then(res=>res.text());
        toggleLoading();
        if (!res) return;
        set({ created: true, designId: res });
    },
    toggleLoading: () => {
        set({ loading: !get().loading });
    }
})
export default createBearSlice

