import {  persist } from 'zustand/middleware'
import log from "@/store/zustand/middleware/log";
import a from "@/store/zustand/model/a";
import b from "@/store/zustand/model/b";
 const presistFn = (data)=>{
     return persist(data,{
             name: 'food-storage', // unique name
             getStorage: () => localStorage, // (optional) by default, 'localStorage' is used
         }
     )
 }
export default presistFn