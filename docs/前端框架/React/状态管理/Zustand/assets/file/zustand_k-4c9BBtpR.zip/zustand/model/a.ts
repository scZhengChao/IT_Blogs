const initialState = { designId: undefined, loading: false ,bears: 0,created:false};

const createFishSlice = (set,get)=>({
    ...initialState,
    increasePopulation: () => set((state) => ({ bears: state.bears + 1 })),
})
export default createFishSlice

