//You can functionally compose your store any way you like.
const log = (config) => (set, get, api) =>
    config(
        (...args) => {
            console.log('  applying', args)
            set(...args)
            console.log('  new state', get())
        },
        get,
        api
    )
export default log