import {IllegalTypeEnum, maxSize} from "@/worker/constants";
import { isEmpty } from 'lodash'
export const checkIllegalFileInfo = (types:IllegalTypeEnum[],fileInfo)=>{
    if(isEmpty(types)){
        return false
    }
    const checkMap = new Map();
    checkMap.set(IllegalTypeEnum.size,fileInfo.file.size > maxSize)
    checkMap.set(IllegalTypeEnum.errorChunk,fileInfo.status === IllegalTypeEnum.errorChunk)
    checkMap.set(IllegalTypeEnum.errorMd5,fileInfo.status === IllegalTypeEnum.errorMd5)
    checkMap.set(IllegalTypeEnum.progressComplete,fileInfo.progress === 100)
    checkMap.set(IllegalTypeEnum.progressFailed,fileInfo.progress === -1)
    return types.find(type=>checkMap.get(type))
}