import {ErrorStatusEnum, maxChunkSize, WorkerTypeEnum} from "@/worker/constants";
import CreateWorkerInstance from "@/worker/create-worker";
export default function createChunk(file) {
    return new Promise((resolve,reject)=>{
        const fileReader = new FileReader()
        try {
            const worker = CreateWorkerInstance.create((data)=>{
                if(data.type === WorkerTypeEnum.成功){
                    resolve(data)
                }else if(data.type === WorkerTypeEnum.成功){
                    reject(ErrorStatusEnum.worker失败)
                }
            })
            if(!worker){
                fileReader.abort()
                reject(ErrorStatusEnum.创建worker超出限制)
                return
            }
            let currentChunk = 0;
            const totalChunks = Math.ceil(file.size/maxChunkSize)
            const processChunk=(start)=>{
                const end = Math.min(start+maxChunkSize,file.size)
                const chunk = file.slice(start,end)
                fileReader.readAsArrayBuffer(chunk)
            }
            fileReader.onload=(e)=>{
                worker?.postMessage({type:WorkerTypeEnum.进行中,payload:e.target.result},[e.target.result])
                if(currentChunk >= totalChunks-1){
                    worker?.postMessage({type:WorkerTypeEnum.结束})
                    fileReader.abort()
                }else{
                    currentChunk += 1
                    processChunk(currentChunk*maxChunkSize)
                }
            }
            fileReader.onerror = e => {
                fileReader.abort()
                reject(e)
            }
            worker?.postMessage({type:WorkerTypeEnum.开始})
            processChunk(currentChunk)
        }catch (e) {
            fileReader.abort()
            reject(e)
        }
    })
}
export const createFileChunk = (file:Blob,size=maxChunkSize):Array<{file:Blob}>=>{
    const chunkList = [];
    let cur = 0;
    while (cur < file.size){
        chunkList.push({file:file.slice(cur,cur+size)})
        cur += size
    }
    return chunkList
}