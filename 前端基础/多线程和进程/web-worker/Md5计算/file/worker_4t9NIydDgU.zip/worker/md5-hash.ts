import SparkMD5 from 'spark-md5'
import { createMD5 } from 'hash-wasm'

class Md5Hash{
    public type;
    public maker;
    public bufferList;
    constructor(bufferList) {
        this.bufferList = bufferList;
        return this.startCalculation()
    }
    startCalculation=()=>{
        return new Promise((resolve,reject)=>{
            this.create().then(()=>{
                this.bufferList.forEach(buffer=>{
                    this.append(buffer)
                })
                const str = this.end()
                resolve(str)
            }).catch(_e=>{
                reject()
            })
        })
    }
    create =  async (type?:string)=>{
        this.type = type;
        if(!type){
            if(typeof WebAssembly === 'object' && typeof WebAssembly.instantiate === 'function'){
                this.type = 'hash-wasm';
                this.maker = await createMD5()
                this.maker.init()
            }else{
                this.type = 'spark-md5';
                this.maker = new SparkMD5.ArrayBuffer()
            }
            return
        }
        if(type === 'spark-md5'){
            this.maker = new SparkMD5.ArrayBuffer();
        }else{
            this.maker = await createMD5()
            this.maker.init()
        }
    }
    append(dataBuffer){
        if(this.type === 'spark-md5'){
            this.maker.append(dataBuffer)
        }else{
            this.maker.update(new Uint8Array(dataBuffer))
        }
    }
    end(){
        if(this.type === 'spark-md5'){
            const result = this.maker.end()
            this.maker.destroy()
            return result;
        }else{
            return this.maker.digest()
        }
    }
}
export default Md5Hash