import { noop } from "lodash"
import {WorkerStatusEnum, WorkerTypeEnum} from "@/worker/constants";


class WorkerItem{
    public worker;
    public callback;
    constructor(worker,callback) {
        this.worker=worker;
        this.callback = callback
    }
    postMessage(...args){
        if(this.worker.id === this.callback){
            this.setStatus(WorkerStatusEnum.md5)
            this.worker.postMessage(...args)
        }
    }
    setStatus(status:WorkerStatusEnum){
        this.worker.status = status
    }
}
class CreateWorker {
    cpus:number=Math.floor(navigator.hardwareConcurrency*1.5);
    workerList=[]
    constructor() {
        if(!CreateWorker.instance){
            CreateWorker.instance = this;
        }
        return CreateWorker.instance
    }
    create = (callback=noop)=>{
        if(this.workerList.length > this.cpus*2) {
            // 不在创建新的worker
            const worker = this.findIdle()
            if(worker){
                this.config(worker,callback)
                return new WorkerItem(worker,callback)
            }
            return
        }
        const worker = new Worker(new URL('@/worker/md5.worker.ts', import.meta.url));
        this.workerList.push(worker)
        this.config(worker,callback)
        return new WorkerItem(worker,callback)
    }
    findIdle(){
        return this.workerList.find(item=>item?.status === WorkerStatusEnum.空闲)
    }
    config(worker,callback){
        worker.status = WorkerStatusEnum.空闲
        worker.id = callback
        worker.onerror=()=>{
            this.close(worker)
        }
        worker.addEventListener = null
        worker.onmessage = (e)=>{
            if(e?.data?.type === WorkerTypeEnum.下一个){
                worker.setStatus(WorkerStatusEnum.空闲)
            }
            callback(e.data)
        }
        worker.onmessageerror =()=>{
            worker.setStatus(WorkerStatusEnum.空闲)
            console.log('序列化失败')
        }
    }

    close(worker){
        if(!worker) return
        worker.terminate()
        const index = this.workerList.findIndex(item=>item === worker)
        if(index !== -1){
            this.workerList.splice(index,1)
        }
    }
    closeAll(){
        this.workerList.forEach(worker=>{
            this.close(worker)
        })
    }
}

export default new CreateWorker()