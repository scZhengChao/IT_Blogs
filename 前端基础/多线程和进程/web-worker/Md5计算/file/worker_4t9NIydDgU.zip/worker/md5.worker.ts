import Md5Hash from './md5-hash'
import {WorkerTypeEnum} from "@/worker/constants";

let bufferList=[]
function beginMd5(){
    const md = new Md5Hash(bufferList)
    md.then(str=>{
        bufferList = []
        self.postMessage({type:WorkerTypeEnum.成功,payload:str});
    }).catch(e=>{
        bufferList = []
        self.postMessage({type:WorkerTypeEnum.失败});
    }).finally(()=>{
        self.postMessage({type:WorkerTypeEnum.下一个});
    })

}
self.addEventListener('message',event=>{
    const {type,payload} = event.data;
    if(type === WorkerTypeEnum.开始){
        bufferList=[]
    }
    if(type === WorkerTypeEnum.进行中){
        bufferList.push(payload)
    }
    if(type === WorkerTypeEnum.结束){
        beginMd5()
    }
})