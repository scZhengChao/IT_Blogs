export const mockApi = (data?:any)=>{
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            const num = parseInt(Math.random()*10) +1
            if(num>1){
                resolve({success:1})
            }else{
                reject({error:1})
            }
        },200)
    })
}
export const smallUpload = (fileInfo:any)=>{
    return mockApi()
}


export const init= ()=>{
    return mockApi()
}
export const head = ()=>{
    return mockApi()
}
export const end = ()=>{
    return mockApi()
}
export const create=()=>{
    return mockApi()
}