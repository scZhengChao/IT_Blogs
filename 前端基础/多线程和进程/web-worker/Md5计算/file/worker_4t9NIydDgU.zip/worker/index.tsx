import React, {memo, useCallback, useEffect, useMemo, useRef, useState} from 'react';
import { history } from '@umijs/max'
import { useEventEmitter } from 'ahooks'

import {
    concat,
    from,
    interval,
    mergeMap,
    Observable,
    of,
    scan,
    Subject,
    takeWhile,
    tap,
    filter,
    distinct,
    map, catchError,
    concatMap, concatAll, forkJoin,
} from 'rxjs';
import { useMount} from 'ahooks'
import { Button } from 'antd'
import CreateWorkerInstance from "@/worker/create-worker";
import createChunk from "@/worker/create-chunk";
import  {rx,bigFileRx} from "@/worker/rxjsQuene";
import {workerMd5} from "@/worker/worker-md5";
import {IllegalTypeEnum, maxChunkSize, maxNetPool, maxSize} from "@/worker/constants";
import { end, head, init, mockApi, smallUpload,create} from "@/worker/mockApi";
import { createFileChunk } from '@/worker/create-chunk'
import { checkIllegalFileInfo } from "@/worker/utils"
function httpGet(url) {
    return new Promise(resolve => setTimeout(() => resolve(`Result: ${url}`), 2000));
}
// 模拟下载过程
const virtualDownload = () => {
    const speed = Math.random() * 0.3;
    return interval(1000).pipe(
        scan((acc) => Math.min(1, acc + speed), 0),
        mergeMap((percent) => {
            if (percent >= 1) {
                return concat(of(percent), of(null));
            }
            return of(percent);
        }),
        takeWhile(v => typeof v === 'number'),
    ) as Observable<number>;
};

interface VirtualFile {
    name: string;
    percent: number;
    status: 'done' | 'waiting' | 'pending';
}


const Home = memo((props) => {
    const [files, setFiles] = useState<VirtualFile[]>([]);
    const rxFiles = useRef([])
    const downloadTrigger = useRef(useMemo(() => {
        return new Subject<string>();
    }, []));
    const event$ = useEventEmitter();

    const onClick = useCallback(() => {
        const filename = `${Math.random()}.zip`; // 随机模拟一个文件名
        downloadTrigger.current.next(filename);
    }, [files.length]);

    useEffect(()=>{
        let  i = 0;
        const subscription = rx.pipe(
            filter((fileInfo)=>{
                return fileInfo.file.size <= maxSize
            }),
            distinct((fileInfo)=>fileInfo.file.name),
            tap((fileInfo)=>{
                console.log('过滤重复和大小之后打印----',fileInfo)
                rxFiles.current.push(fileInfo)
            }),
            mergeMap((fileInfo)=>{
                return from(createChunk(fileInfo.file).then(res=>{
                    fileInfo.md5 = res.payload
                    return fileInfo
                }).catch(e=>{
                    fileInfo.md5 = ''
                    fileInfo.status = IllegalTypeEnum.errorMd5
                    return fileInfo
                }))
            },CreateWorkerInstance.cpus),
            tap(()=>{
                if(rxFiles.current.filter(item=>item.md5).length === rxFiles.current.length){
                    console.log('---worker已全部销毁')
                    CreateWorkerInstance.closeAll()
                }
            }),
            mergeMap((fileInfo)=>{
                fileInfo.bufferList = []
                if(checkIllegalFileInfo([IllegalTypeEnum.errorMd5,IllegalTypeEnum.errorChunk],fileInfo)){
                    return  of(fileInfo)
                }
                return from(mockApi(fileInfo).then(res=>{
                    fileInfo.progress = 0;
                    return fileInfo
                }).catch(e=>{
                    fileInfo.progress = 0;
                    return fileInfo
                }))
            },maxNetPool),
            tap((fileInfo)=>{
                console.log('上传之前打印----',fileInfo)
            }),
            mergeMap((fileInfo)=>{
                if(checkIllegalFileInfo([IllegalTypeEnum.progressComplete,IllegalTypeEnum.errorMd5,IllegalTypeEnum.errorChunk],fileInfo)){
                    return  of(fileInfo)
                }
                if(fileInfo.file.size <=  maxChunkSize){
                    // 小文件
                    return from(smallUpload(fileInfo).then(res=>{
                        fileInfo.progress = 100;
                        return fileInfo
                    }).catch(e=>{
                        fileInfo.progress = -1
                        return fileInfo
                    }))
                }
                if(fileInfo.file.size > maxChunkSize){
                    // 大文件
                    return of(fileInfo)
                }
            },maxNetPool),
        ).subscribe({
            next:(fileInfo)=>{
                if(checkIllegalFileInfo([
                    IllegalTypeEnum.progressComplete,
                    IllegalTypeEnum.progressFailed,
                    IllegalTypeEnum.errorMd5,
                    IllegalTypeEnum.errorChunk
                ],fileInfo)){
                    console.log('---smalll---',fileInfo)
                    // 这边是已经有明确结果的；当然是针对大文件;
                    // 所以这边的接口要么是100；要么是失败
                    // 中间状态；setState 去刷新页面吧；
                }else{
                    // 单独上传大文件
                    bigFileRx.next(fileInfo)
                }
            },
            error:(err)=>{
                console.log(err,'---err----')
            },
            complete:()=>{
                console.log('complete,')
            }
        })
        return ()=>{
            subscription.unsubscribe();
        }
    },[])
    useEffect(()=>{
        const subscriptionBig = bigFileRx.pipe(
            concatMap(async fileInfo=>{
                console.log('big--file---jion---',fileInfo.file.name)
                function groupChunk(list){
                    let i = 0;
                    const  groupArr = []
                    while (i < list.length){
                        groupArr.push(list.slice(i,i+maxNetPool))
                        i += maxNetPool
                    }
                    return groupArr
                }
                try {
                    await init();
                    await head()
                    const chunkLists = createFileChunk(fileInfo.file)
                    fileInfo.files = chunkLists
                    const chunkGroup = groupChunk(chunkLists)
                    for(let i = 0 ;i<chunkGroup.length;i++){
                        await Promise.all(chunkGroup[i].map(params=>mockApi(params)))
                    }
                    await end()
                    await create()
                    fileInfo.progress = 100;
                    return of(fileInfo)
                }catch (e) {
                    fileInfo.progress = -1;
                    return of(fileInfo)
                }
            }),
            concatAll()
        ).subscribe({
            next:(fileInfo)=>{
                console.log(fileInfo?.file?.name,'--bigFileRx--next--')
            },
            complete:()=>{
                console.log('--bigFileRx--complete--')
            },
            error:(e)=>{
                console.log(e,'--bigFileRx--error--')
            }
        })
        return ()=>{
            subscriptionBig.unsubscribe()
        }
    },[])
    const onChange = (e)=>{
        const files = Array.from(e.target.files);
        files.forEach(file=>{
            rx.next({
                file:file,
                bufferList:[],
                md5:'',
                status:0,
                progress:0
            })
        //     createChunk(file).then(bufferList=>{
        //         const worker = CreateWorkerInstance.create((data)=>{
        //             console.log(data,'--data--')
        //             console.timeEnd('md5')
        //         })
        //         if(worker){
        //             worker?.postMessage({type:'createMd5:start'})
        //             bufferList.forEach(buffer=>{
        //                 worker?.postMessage({type:'createMd5:ing',payload:buffer},[buffer])
        //             })
        //             worker?.postMessage({type:'createMd5:end'})
        //         }
        //     }).catch(e=>{
        //
        //     })
        })

    }
    useEffect(() => {
        const subscription = downloadTrigger.current.pipe(
            mergeMap(name => {
                const newFile: VirtualFile = {
                    name,
                    percent: 0,
                    status: 'waiting',
                };
                console.log(name,'----name---')
                setFiles(prev => {
                    const next = [...prev];
                    next.push(newFile);
                    return next;
                });
                return of(newFile);
            }),
            mergeMap((value) => {
                console.log(value,'---value--')
                return virtualDownload().pipe(
                    tap((percent) => {
                        value.percent = percent;
                        value.status = percent < 1 ? 'pending' : 'done';
                        setFiles(prev => [...prev]);
                    }),
                );
            }, 3), // 3为最大并发数
        ).subscribe((data)=>{
            console.log(data,'---data----')
        });
        return () => {
            subscription.unsubscribe();
        };
    }, []);
    return (
          <div>
              <div>
                  <Button onClick={onClick}>添加下载任务</Button>
                  <span>点击左侧按钮添加任务</span>
              </div>
              <ul>
                  {
                      files.map(v => {
                          return (
                              <li key={v.name}>
                                  <span>{v.name}</span>
                                  <span >{(v.percent * 100).toFixed(2)}%</span>
                                  <span
                                  >{v.status === 'waiting' ? '等待中' : v.status === 'pending' ? '下载中' : '已完成'}</span>
                              </li>
                          );
                      })
                  }
              </ul>
              <input type={'file'} onChange={onChange} multiple={true}/>
          </div>
    )
});
Home.displayName = 'Home';

export default Home;