export const maxChunkSize = 1024 * 1024 * 50// 每次处理数据块的最大值，50MB
export const maxSize = 1024*1024*1024 * 5
export const maxNetPool = 6
export enum WorkerStatusEnum {
    空闲=0,
    任务=1,
    md5=3
}
export enum WorkerTypeEnum {
    开始='createMd5:start',
    进行中='createMd5:ing',
    结束='createMd5:end',
    成功='createMd5:success',
    失败='createMd5:fail',
    下一个='createMd5:next',
}
export enum ErrorStatusEnum {
    worker失败='worker-md5:failed',
    创建worker超出限制='worker-md5:over'
}

export enum IllegalTypeEnum {
    size='size',
    errorChunk='error:chunk',
    errorMd5='error:md5',
    progressComplete='progress:complete',
    progressFailed='progress:Failed'
}