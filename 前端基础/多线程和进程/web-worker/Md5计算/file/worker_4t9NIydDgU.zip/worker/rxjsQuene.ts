import {mergeMap, Subject} from 'rxjs'
import {IllegalTypeEnum, maxSize} from "@/worker/constants";
export const rx = new Subject()
export const bigFileRx = new Subject()
import {isEmpty } from 'lodash'


class RxjsQueue {
    constructor() {

    }
}