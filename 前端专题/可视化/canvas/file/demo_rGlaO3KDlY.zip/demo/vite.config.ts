import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path  from "path"
import svgr from "vite-plugin-svgr"
const resolve = function (dir:string){
  return path.resolve(__dirname, dir)
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [svgr(),react()],
  resolve:{
    alias:{
      '@':resolve('src')
    }
  }
})
