import styles from './App.module.less'
import FJImgCreate from "@/components/FJImgCreate";
import FJSlider from "@/components/FJSlider";
import FJImgList from "@/components/FJImgList";
import FjTabs from "@/components/FJTabs";
function App() {

  return (
    <div className={styles.container}>
        <FJSlider/>
        <FjTabs
            defaultActiveKey="1"
            className={styles.rightContainer}
            items={[
                {
                    label: 'Creations',
                    key: '1',
                    children: <FJImgCreate/>
                },
                {
                    label: 'History',
                    key: '2',
                    children: <FJImgList/>
                },


            ]}
        />
    </div>
  )
}

export default App
