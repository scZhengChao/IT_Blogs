import {memo, useRef, useState} from 'react';
import styles from './index.module.less';
import { useMount } from 'ahooks'

interface ImgListProps{
    width:number;
    height:number;
    content:string
}
const IMG_WIDTH = 80
const FJImgList = memo(() => {
    const parentBox = useRef<HTMLDivElement>(null)
    const [imgList,setImgList ] = useState<ImgListProps[]>([])
    useMount(()=>{
        // 随机生成 40张等高不等宽的图片
        const arr = new Array(50).fill('').map((v,i)=>{
            const height = Math.ceil(Math.random()*100) + 60
            return {
                width:IMG_WIDTH,
                height:height,
                content:`宽${IMG_WIDTH}高${height}的图片${i}`,
            }
        })
        setImgList(arr)
    })
    return <div className={styles.container}>
        <div className={styles.img_list_box} ref={parentBox}>
            {imgList.map((imgInfo,i)=>{
                return <div style={{width:'100%',height:imgInfo.height}} className={styles.img_basic_style} key={i}>{imgInfo.content}</div>
            })}
        </div>
    </div>
});

export default FJImgList;