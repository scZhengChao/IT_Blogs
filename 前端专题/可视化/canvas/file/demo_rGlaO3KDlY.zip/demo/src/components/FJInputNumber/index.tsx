import {memo, useEffect, useRef, useState} from 'react';
import styles from './index.module.less';


interface FjInputNumberProps {
  min:number;
  max:number;
  onChangeValue:(num:number)=>void;
  value?:number;
  className?:string;
  defaultValue?:number
}

const FJInputNumber = memo<FjInputNumberProps>((props) => {
  const {
      min,
      max,
      onChangeValue,
      value,
      className='',
      defaultValue = 0
  } = props
    const inputNumberEl = useRef<HTMLInputElement>()
    const [num,setNum] = useState<number>(defaultValue)
    useEffect(()=>{
        if(typeof  value === 'number'){
            setNum(value)
        }
    },[value])
    const onBlur = ()=>{
        const inputEl = inputNumberEl.current!
        const legalNumber = Math.max(Number(inputEl.min), Math.min(Number(inputEl.max), Number(inputEl.value)))
        inputEl.value = String(legalNumber)
        onChangeValue(legalNumber)
    }
    const onChange = (e:React.ChangeEvent<HTMLInputElement>)=>{
        setNum(Number(e.target.value))
    }
    return <input
      value={num}
      type='number'
      className={`${styles.number_range} ${className}`}
      onChange={onChange}
      onBlur={onBlur}
      min={min}
      max={max}
      ref={inputNumberEl}
    />

});
FJInputNumber.displayName = 'FJInputNumber';

export default FJInputNumber;