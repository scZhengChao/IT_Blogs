import {memo, useRef} from 'react';
import styles from './index.module.less';
import {useMount} from 'ahooks'
import { useSelector} from 'react-redux'
import type {  StateTypes} from "@/store";
import useDrawAndEraseCanvasHook from "@/hooks/useDrawAndEraseCanvasHook.ts";
import fjClearImgInstance from "@/manager/FJClearImgManager.ts";
const FJImgCreate = memo(() => {
    const canvasParentEl = useRef<HTMLDivElement>(null);
    const canvasEl = useRef<HTMLCanvasElement>(null);
    const position = useDrawAndEraseCanvasHook(canvasEl)
    const cursorSize = useSelector<StateTypes, number>(state => state.cursorSize);
    useMount(() => {
        fjClearImgInstance.loadBasicObject()
        const observer = new ResizeObserver(entries => {
            for (const entry of entries) {
                if (entry.target === canvasParentEl.current) {
                    fjClearImgInstance.reSizeCanvas(entry.contentRect.width,entry.contentRect.height)
                }
            }
        });
        observer.observe(canvasParentEl.current!);
    })
    return <div className={styles.img_section_container} ref={canvasParentEl} data-over={position.isOver}>
        <div className={styles.cursor} style={{width: cursorSize, height: cursorSize,transform: `translate3d(${position.x-cursorSize/2}px, ${position.y-cursorSize/2}px,0)`}}></div>
        <canvas id='customCanvasId' className={styles.custom_canvas_style} ref={canvasEl}></canvas>
    </div>
});

export default FJImgCreate;