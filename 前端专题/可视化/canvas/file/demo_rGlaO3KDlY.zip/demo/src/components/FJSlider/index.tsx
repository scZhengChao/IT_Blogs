import { memo, useRef} from 'react';
import type { FormEvent } from 'react'
import { Slider} from 'antd'
import styles from './index.module.less';
import uploadIcon from '@/assets/uploadIcon.png'
import eraserPng from '@/assets/eraser.png'
import pencilPng from '@/assets/pencil.png'
import {useDispatch, useSelector} from 'react-redux'
import type {  StateTypes} from "@/store";
import  {ActionTypesEnum,CursorTypeEnum } from "@/store";
import type { InputNumberProps } from 'antd';
import fjClearImgInstance from "@/manager/FJClearImgManager.ts";
import FjButton from "@/components/FJButton";
import FjRange from "@/components/FJRange";

const FJSlider = memo(() => {
    const inputRef = useRef<HTMLInputElement>(null)
    const dispatch = useDispatch();
    const cursorSize = useSelector<StateTypes, number>(state => state.cursorSize);
    const cursorType = useSelector<StateTypes, CursorTypeEnum>(state => state.cursorType);
    const stepRatio = useSelector<StateTypes, number>(state => state.stepRatio);


    const onUpload = ()=>{
        inputRef.current?.click()
    }
    const inputFile =async (e:FormEvent<HTMLInputElement>)=>{
        const file:File = e.target.files[0]
        await fjClearImgInstance.readImgToCanvas(file,dispatch)
        dispatch({type:ActionTypesEnum.CHANGE_DRAW_TYPE,payload:CursorTypeEnum.pencil})
    }
    const onChangePencilMode = ()=>{
        dispatch({type:ActionTypesEnum.CHANGE_DRAW_TYPE,payload:CursorTypeEnum.pencil})
    }
    const onChangeEraserMode = ()=>{
        dispatch({type:ActionTypesEnum.CHANGE_DRAW_TYPE,payload:CursorTypeEnum.eraser})
    }
    const onChangeSize: InputNumberProps['onChange'] = (newValue) => {
        dispatch({type:ActionTypesEnum.CHANGE_PENCIL_SIZE,payload:newValue as number})
    };
    const onChangeScaleRadio: InputNumberProps['onChange'] = (newValue) => {
        dispatch({type:ActionTypesEnum.CHANGE_RADIO_STEP,payload:newValue as number})
        fjClearImgInstance.scaleAtCenterDraw()
    };
    const onReset=()=>{
        dispatch({type:ActionTypesEnum.CHANGE_RADIO_STEP,payload:1})
        fjClearImgInstance.scaleAtCenterDraw()
    }

  return <div className={styles.left_section}>
      <div className={styles.upload_btn} onClick={onUpload}>
          <img src={uploadIcon} alt='' className={styles.upload_img}/>
          <div>上传图片</div>
          <input type="file" className={styles.img_input} accept=".jfif,.jpg,.webp,.jpeg,.png,.tiff,.bmp" ref={inputRef} onInput={inputFile} />
      </div>
      <div className={styles.mode_box} >
            <div className={styles.mode_box_item} data-active={cursorType===CursorTypeEnum.eraser} onClick={onChangeEraserMode}>
                <div className={styles.border_content}>
                    <img src={eraserPng} alt='' className={styles.mode_icon}/>
                    <div>Erase</div>
                </div>
            </div>
          <div className={styles.mode_box_item} data-active={cursorType===CursorTypeEnum.pencil} onClick={onChangePencilMode}>
              <div className={styles.border_content}>
                  <img src={pencilPng} alt='' className={styles.mode_icon}/>
                  <div>Pencil</div>
              </div>
          </div>
      </div>
      <FjRange
          min={2}
          max={100}
          value={typeof cursorSize === 'number' ? cursorSize : 2}
          defaultValue={30}
          onChange={onChangeSize}
          label="Size"
          step={1}
      />
      <FjRange
          min={0.1}
          max={10}
          value={typeof stepRatio === 'number' ? stepRatio : 1}
          defaultValue={30}
          onChange={onChangeScaleRadio}
          label="Scale Canvas"
          step={0.1}
          className={styles.last_range}
      />
      <FjButton onClick={onReset}>还原</FjButton>
  </div>
});

export default FJSlider;