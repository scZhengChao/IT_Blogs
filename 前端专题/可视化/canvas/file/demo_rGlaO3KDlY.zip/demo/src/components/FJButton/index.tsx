import { memo } from 'react';
import type { PropsWithChildren } from 'react'
import styles from './index.module.less';
interface FjButtonProps {
    activeBorderColor?:string;
    activeTextColor?:string
    onClick?:(e:React.MouseEvent<HTMLDivElement>) => void
}

const FjButton = memo((props:PropsWithChildren<FjButtonProps>) => {
    const { children,
        activeBorderColor='#0048ff',
        activeTextColor='#0048ff',
        onClick=arg=>arg,
    } = props
    return <div
        className={styles.common_button_style}
        style={{
            '--activeBorderColor':activeBorderColor,
            '--activeTextColor':activeTextColor
        }}
        onClick={onClick}
    >{children}</div>
});
FjButton.displayName = 'FjButton';

export default FjButton;