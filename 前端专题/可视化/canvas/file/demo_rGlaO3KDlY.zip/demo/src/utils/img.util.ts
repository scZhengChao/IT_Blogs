
export const readImgToCanvas = (file:File,canvasId:string)=>{
    const fileReader = new FileReader()
    const canvas = document.querySelector(canvasId)
    if(!canvas) return
    const ctx = canvas.getContext('2d')
    fileReader.readAsDataURL(file)
    fileReader.onload = e => {
        const img = document.createElement('img')
        img.src = e.target!.result as string
        img.onload = () => {
            const canvasArea = [0,0, canvas.width, canvas.height]
            const ratio = img.width>canvas.width? canvas.width/img.width:1
            const wh = [img.width * ratio*0.8, img.height * ratio*0.8]
            ctx.clearRect(...canvasArea)
            const dx = Math.floor((canvas.width - wh[0])/2)
            const dy = Math.floor((canvas.height- wh[1])/2)
            ctx.drawImage(img, dx, dy, ...wh)
        }
    }
}
