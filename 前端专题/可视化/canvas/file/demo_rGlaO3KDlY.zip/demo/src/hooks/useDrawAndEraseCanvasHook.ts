
import { useEventListener, } from 'ahooks'
import { useRef,useState} from "react";
import type { RefObject} from 'react'
import {useSelector} from "react-redux";
import {CursorTypeEnum } from "@/store";
import type { StateTypes } from "@/store";
import fjClearImgInstance from "@/manager/FJClearImgManager.ts";
interface OptimizeDrawProps {
    animationId:number | null;
    points:{x:number,y:number}[]
}
const useDrawAndEraseCanvasHook  = (canvas:RefObject<HTMLCanvasElement>)=>{
    const isMouseDown =  useRef<boolean>(false)
    const cursorType = useSelector<StateTypes,CursorTypeEnum>(state => state.cursorType);
    const cursorSize = useSelector<StateTypes, number>(state => state.cursorSize);
    const [position,setPosition] = useState({x:0,y:0,isOver:false})
    const drawCtx = fjClearImgInstance.getDrawCtx()
    const optimizeDraw = useRef<OptimizeDrawProps>({
        animationId:0,
        points:[]
    })
    const draw = ()=>{
        const points = optimizeDraw.current.points
        const currentPoints  = points.splice(0, points.length)
        for (let i = 0; i < currentPoints.length; i++) {
            const x = currentPoints[i].x
            const y = currentPoints[i].y
            drawCtx!.lineTo(x, y);
        }
        drawCtx!.stroke()
        fjClearImgInstance.scaleAtCenterDraw()
        if(points.length>0){
            requestAnimationFrame(draw)
        }else{
            cancelAnimationFrame(optimizeDraw.current.animationId!)
            optimizeDraw.current.animationId = null;
        }
    }
    useEventListener(
        'mousedown',
        (e) => {
            if(!fjClearImgInstance.hasOriginImg()) return;
            if (e.button) return
            if(!drawCtx) return;
            const { x , y} = fjClearImgInstance.getMousePosition(e)
            if(!fjClearImgInstance.isInImage(x,y)) return
            isMouseDown.current = true
            drawCtx.beginPath()
            drawCtx.moveTo(x , y)
            const isEraser = cursorType === CursorTypeEnum.eraser
            drawCtx.globalCompositeOperation = isEraser ? 'destination-out' : 'source-over'
            drawCtx.strokeStyle = isEraser ? 'rgba(0,0,0,1)' : 'rgba(151,152,253,0.8)'

            drawCtx.lineWidth = isEraser ? cursorSize : cursorSize
        },
        { target: canvas }
    )
    useEventListener(
        'mousemove',
        (e) => {
            setPosition({
                ...position,
                x:e.offsetX,
                y:e.offsetY,
                isOver:true
            })
            if(!isMouseDown.current) return
            if(!drawCtx) return;
            const { x , y} = fjClearImgInstance.getMousePosition(e)
            if(!fjClearImgInstance.isInImage(x,y)) {
                drawCtx.beginPath()
                return
            }
            optimizeDraw.current.points.push({x,y})
            if(!optimizeDraw.current.animationId){
                optimizeDraw.current.animationId = requestAnimationFrame(draw)
            }
        },
        { target: canvas }
    )
    const cancelAnimation = ()=>{
        optimizeDraw.current.points = [];
        const animationId = optimizeDraw.current.animationId
        if (animationId) {
            cancelAnimationFrame(animationId);
            optimizeDraw.current.animationId = null;
        }
    }
    useEventListener(
        'mouseup',
        () => {
            if(!drawCtx) return;
            isMouseDown.current = false
            setPosition({
                ...position,
                isOver:false
            })
            fjClearImgInstance.cloneDrawCanvas()
            cancelAnimation()
        },
        { target: document }
    )
    useEventListener(
        'mouseleave',
        () => {
            if(!drawCtx) return;
            setPosition({
                ...position,
                isOver:false
            })
            drawCtx.beginPath()
            cancelAnimation()
        },
        { target: canvas }
    )
    return position
}
export default useDrawAndEraseCanvasHook