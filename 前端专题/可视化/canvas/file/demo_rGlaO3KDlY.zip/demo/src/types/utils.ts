
export type AutoOrNull<T> = T | null