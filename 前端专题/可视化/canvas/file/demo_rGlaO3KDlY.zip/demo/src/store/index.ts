// store.js
import { createStore } from 'redux';

export enum ActionTypesEnum {
    'CHANGE_PENCIL_SIZE'='CHANGE_PENCIL_SIZE', //  修改铅笔粗细
    'CHANGE_DRAW_TYPE'='CHANGE_DRAW_TYPE', // 修改模式：橡皮擦模式 和 铅笔模式
    'CHANGE_SCALE_RATIO'='CHANGE_SCALE_RATIO', // 自适应的缩放比
    'CHANGE_RADIO_STEP'='CHANGE_RADIO_STEP', // 手动改变缩放比
}
export enum CursorTypeEnum {
    pencil='pencil',
    eraser='easeEraser'
}
interface ActionTypes {
    type:ActionTypesEnum
    payload:unknown
}
export interface CanvasPositionProps {
    width:number;
    height:number;
    top:number;
    left:number
}
export interface StateTypes {
    cursorSize:number;
    cursorType:CursorTypeEnum;
    scaleRatio:number;
    stepRatio:number;
}
// 初始状态
const initialState = {
    cursorSize: 10,
    cursorType:null,
    scaleRatio:1,
    stepRatio:1,
};

// reducer 函数
const rootReducer = (state:StateTypes = initialState, action:ActionTypes) => {
    switch (action.type) {
        case ActionTypesEnum.CHANGE_PENCIL_SIZE :{
            return { ...state, cursorSize: action.payload as number };
        }
        case ActionTypesEnum.CHANGE_DRAW_TYPE:{
            return { ...state, cursorType: action.payload as CursorTypeEnum };
        }
        case ActionTypesEnum.CHANGE_SCALE_RATIO:{
            return { ...state, scaleRatio: action.payload as number };
        }
        case ActionTypesEnum.CHANGE_RADIO_STEP:{
            return { ...state, stepRatio: action.payload as number };
        }
        default:
            return state;
    }
};

// 创建 store
const store = createStore(rootReducer);

export default store;