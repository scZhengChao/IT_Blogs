import type {Dispatch, UnknownAction} from "redux";
import store from "@/store";
import { ActionTypesEnum } from '@/store'
import type {AutoOrNull} from "@/types/utils.ts";
class FJClearImgManager {
    originImg:AutoOrNull<HTMLImageElement>  ; // 展现出来的
    originCtx:AutoOrNull<CanvasRenderingContext2D>; // 展现出来的 2d

    imageCanvas:AutoOrNull<HTMLCanvasElement> ; // 存储原始图片
    imgCtx:AutoOrNull<CanvasRenderingContext2D>; // 存储原始图片 2d

    drawCanvas:AutoOrNull<HTMLCanvasElement>; // 存储涂鸦层
    drawCtx:AutoOrNull<CanvasRenderingContext2D> ; // draw 2d

    dispatch:Dispatch<UnknownAction>;
    canvasNode:AutoOrNull<HTMLCanvasElement>; // canvas
    canvasId:string = '#customCanvasId'

    lastDrawImgArea:number[];
    lastDrawScale:number;
    lastDrawCanvas:AutoOrNull<HTMLCanvasElement>
    offset={
        x:0,
        y:0
    }
    get dpr(){
        return window.devicePixelRatio || 1
    }
    hasOriginImg=()=>{
        return !!this.originImg
    }
    getDrawCtx = ()=>{
        return this.drawCtx
    }
    /**
     * 重置所有内容
     */
    resetAll = ()=>{
        this.offset = {x:0,y:0}
        this.lastDrawCanvas = null
        this.lastDrawScale = 1;
        this.lastDrawCanvas = null

        this.originImg = null;
        this.originCtx = null
        this.imageCanvas = null;
        this.imgCtx = null;
        this.drawCanvas = null;
        this.drawCtx = null;
        this.canvasNode = null;

    }
    /**
     * 克隆最后一次 drawCanvas
     */
    cloneDrawCanvas=()=> {
        const drawCanvas = this.drawCanvas!
        // 创建新canvas
        const newCanvas = document.createElement('canvas');
        newCanvas.width = drawCanvas.width;
        newCanvas.height = drawCanvas.height;

        // 绘制原canvas内容到新canvas
        const ctx = newCanvas.getContext('2d')!;
        ctx.drawImage(drawCanvas, 0, 0);
        this.lastDrawCanvas = newCanvas
        this.lastDrawImgArea = this.getImageArea()
        this.lastDrawScale = store.getState().stepRatio
    }

    /**
     * 重绘 drawCanvas
     * @param oldImgArea
     * @param oldScale
     */
    resizeDrawCanvas=()=>{

        const oldImgArea:number[] = this.lastDrawImgArea
        const lastDrawCanvas = this.lastDrawCanvas
        const oldScale = this.lastDrawScale

        oldImgArea[2] = Math.round(oldImgArea[2]/oldScale)
        oldImgArea[3] = Math.round(oldImgArea[3]/oldScale)


        const targetArea = this.getImageArea()

        // 3. 重新绘制内容（自动适应新尺寸）
        this.drawCtx!.drawImage(
            lastDrawCanvas,
            ...oldImgArea,           // 源尺寸
            ...targetArea,           // 目标尺寸
        );
        this.clipPath()
    }

    /**
     * 把图片读进内存
     * @param file
     * @param dispatch
     */
    readImgToCanvas =async (file:File,dispatch:Dispatch<UnknownAction>)=>{
        this.resetAll()
        this.loadBasicObject()
        this.reSizeCanvas(this.canvasNode!.offsetWidth,this.canvasNode!.offsetHeight)
        return new Promise<null>((resolve)=>{
            const fileReader = new FileReader()
            this.dispatch = dispatch
            fileReader.readAsDataURL(file)
            fileReader.onload = e => {
                const img = document.createElement('img')
                img.src = e.target!.result as string
                img.onload = () => {
                    this.originImg = img
                    this.getRatio()
                    this.drawOriginImageCanvas()
                    this.redraw()
                    this.clipPath()
                    this.cloneDrawCanvas()
                    resolve(null)
                }
            }
        })
    }
    /**
     * 剪切区域
     */
    clipPath=()=>{
        if(!this.originImg)  return
        this.drawCtx!.beginPath();
        const imgArea = this.getImageArea()
        this.drawCtx!.rect(
            ...(imgArea as [number,number,number,number])
        );
        this.drawCtx!.clip();
    }
    /**
     * 获取自适应后的图片大小
     */
    getImgArea = ()=>{
        const img = this.originImg
        if(!img) return
        const canvas = this.canvasNode!
        const ratio = store.getState().scaleRatio
        const area = [Math.round(img.width* ratio), Math.round(img.height * ratio)]
        this.offset.x =  Math.round((canvas.width - area[0])/2)
        this.offset.y =  Math.round((canvas.height - area[1])/2)
        return area
    }
    /**
     * 清空canvas
     * @param customCtx
     */
    clearCanvas = (customCtx:CanvasRenderingContext2D)=>{
        const canvas = this.canvasNode!
        const canvasArea:[number,number,number,number] = [0,0, canvas.width, canvas.height]
        customCtx.clearRect(...canvasArea)
    }
    /**
     * 绘制图片
     * @param customCtx
     * @param wh
     */
    drawImgCanvas = (customCtx:CanvasRenderingContext2D,wh:[number,number])=>{
        if(!wh) return
        const img = this.originImg!
        const canvas = this.canvasNode!
        const dx = Math.floor((canvas.width - wh[0])/2)
        const dy = Math.floor((canvas.height- wh[1])/2)
        customCtx.drawImage(img, dx, dy, ...wh)
    }


    /**
     * 绘制元素图片
     */
    drawOriginImageCanvas = ()=>{
        if(!this.imageCanvas) return
        if(!this.imgCtx) return
        if(!this.originImg) return;
        this.clearCanvas(this.imgCtx)
        const wh = this.getImgArea() as [number,number]
        this.drawImgCanvas(this.imgCtx,wh)
    }
    /**
     * 初始挂在一些对象
     */
    loadBasicObject = ()=>{
        this.canvasNode = document.querySelector(this.canvasId) as HTMLCanvasElement
        this.imageCanvas =  document.createElement('canvas');
        this.drawCanvas = document.createElement('canvas');
        this.drawCtx = this.drawCanvas.getContext('2d')!
        this.originCtx = this.canvasNode.getContext('2d')!
        this.imgCtx = this.imageCanvas.getContext('2d')!

        this.drawCtx.lineCap = 'round'
        this.drawCtx.lineJoin = 'round'
    }
    /**
     * 更新canvas宽高
     * @param width
     * @param height
     */
    updateCanvasSize= (width:number,height:number)=>{
        const updateCanvas = [this.canvasNode,this.imageCanvas,this.drawCanvas]
        updateCanvas.forEach(canvas=>{
            canvas!.width = width*this.dpr
            canvas!.height = height*this.dpr
        })
    }
    /**
     * 获取图片自适应的比列；也就是初始值
     */
    getRatio=()=>{
        if(!this.originImg) return
        if(!this.canvasNode) return
        const img = this.originImg ;
        const canvas = this.canvasNode
        const imgRatio = img.width / img.height;
        const canvasRatio = canvas.width / canvas.height;
        const ratio = imgRatio > canvasRatio
            ? (img.width<canvas.width?1: canvas.width/img.width)
            : (img.height<canvas.height?1: canvas.height/img.height);
        this.dispatch({type:ActionTypesEnum.CHANGE_SCALE_RATIO,payload:ratio as number})
        return  ratio
    }
    /**
     * 转换鼠标坐标
     * @param e
     */
    getWheelScale = ()=>{
        const canvas = this.canvasNode!
        if(!canvas) return {
            scaleX:1,
            scaleY:1
        }
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;   // 水平缩放比
        const scaleY = canvas.height / rect.height; // 垂直缩放比
        return {
            scaleX,
            scaleY
        }
    }
    getMousePosition=(e:MouseEvent)=>{
        const scaleFactor = store.getState().stepRatio;
        const canvas = this.canvasNode!
       const { scaleX,scaleY} = this.getWheelScale()

        const gapWidth = (canvas.width*scaleFactor - canvas.width)/2
        const gapHeight = ( canvas.height*scaleFactor - canvas.height)/2

        const x = (e.offsetX*scaleX + gapWidth)/scaleFactor
        const y =(e.offsetY*scaleY + gapHeight)/scaleFactor

        return {
            x,y
        }
    }
    /**
     * 当canvas 的尺寸发生改变时；充值canvas；
     * @param width
     * @param height
     */
    reSizeCanvas = (width:number,height:number)=>{
        fjClearImgInstance.updateCanvasSize(width,height)
        if(!this.originImg) return
        store.dispatch({type:ActionTypesEnum.CHANGE_RADIO_STEP,payload:1})
        fjClearImgInstance.getRatio()
        fjClearImgInstance.drawOriginImageCanvas()
        fjClearImgInstance.resizeDrawCanvas()
        fjClearImgInstance.scaleAtCenterDraw()
    }

    /**
     * 获取图片区域的x，y ，widht，height
     */
    getImageArea=():number[]=>{
        if(!this.originImg) return []
        const img = this.originImg
        const scaleFactor = store.getState().stepRatio;
        const ratio = store.getState().scaleRatio
        return [this.offset.x,this.offset.y,Math.round(img.width*scaleFactor*ratio), Math.round(img.height*scaleFactor*ratio)]
    }
    /**
     * 判断是否在图片内
     * @param x
     * @param y
     */
    isInImage=(x:number,y:number)=>{
        const canvas = this.canvasNode!
        const isXInner = x >= Math.ceil(this.offset.x) && x <= Math.floor(canvas.width-this.offset.x)
        const isYInner =  y >= Math.ceil(this.offset.y) && y <= Math.floor(canvas.height-this.offset.y);
        return  isXInner && isYInner
    }
    /**
     * 正确的重绘函数（合并原始图片和涂鸦层）
     */
    redraw = ()=>{
        this.clearCanvas(this.originCtx!)
        // 1. 先绘制原始图片
        this.originCtx!.drawImage(this.imageCanvas!, 0, 0);
        // 2. 再叠加涂鸦层
        this.originCtx!.drawImage(this.drawCanvas!, 0, 0);
    }
    /**
     * 按照缩放比率绘制
     */
    scaleAtCenterDraw = () =>{
        if(!this.originImg) return
        const scaleFactor = store.getState().stepRatio;
        const canvas = this.canvasNode!

        // 清除画布
        this.originCtx!.clearRect(0, 0, canvas.width, canvas.height);
        const centerX = canvas.width /2
        const centerY = canvas.height /2
        if(scaleFactor === 1){
            this.redraw()
            return;
        }
        // 保存当前状态
        this.originCtx!.save();

        // 1. 平移到中心点
        this.originCtx!.translate(centerX, centerY);
        // 2. 应用缩放
        this.originCtx!.scale(scaleFactor, scaleFactor);
        // 3. 反向平移，使图形坐标以中心为基准
        this.originCtx!.translate(-centerX, -centerY);

        this.redraw()
        this.originCtx!.restore();
    }
}
const fjClearImgInstance = new FJClearImgManager()
export default fjClearImgInstance