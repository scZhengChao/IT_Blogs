  // 上传拓展日志信息的入口
class ExtendBehaviorInfo {
    constructor(userId, behaviorType, behaviorResult, uploadType, description){
        this.userId = userId;
        this.behaviorType = behaviorType;
        this.behaviorResult = behaviorResult;
        this.uploadType = uploadType;
        this.description = description;
        this.happenTime = new Date().getTime(); // 日志发生时间
    }
    // 日志基类, 用于其他日志的继承
    handleLogInfo(type,logInfo) {
        var tempString = localStorage[type] ? localStorage[type] : "";
        localStorage[type] = tempString + JSON.stringify(logInfo) + '$$$';
    };

}
export default ExtendBehaviorInfo