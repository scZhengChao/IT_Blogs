// import './lib/fetchCode';
// import './lib/html2canvas'
import setCommonProperty from './mod/setCommonProperty'
import BehaviorInfo from './mod/log/BehaviorInfo'
import CustomerPV from './mod/log/CustomerPV'
import ExtendBehaviorInfo from './mod/log/ExtendBehaviorInfo'
import HttpLogInfo from './mod/log/HttpLogInfo'
import JavaScriptErrorInfo from './mod/log/JavaScriptErrorInfo'
import LoadPageInfo from './mod/log/LoadPageInfo'
import ResourceLoadInfo from './mod/log/ResourceLoadInfo'
import ScreenShotInfo from './mod/log/ScreenShotInfo'
import VideosInfo from './mod/log/VideosInfo'

// polyFile 如果不支持 window.CustomEvent
(function () {
	if ( typeof window.CustomEvent === "function" ) return false;
	function CustomEvent ( event, params ) {
		params = params || { bubbles: false, cancelable: false, detail: undefined };
		var evt = document.createEvent( 'CustomEvent' );
		evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
		return evt;
	}
	CustomEvent.prototype = window.Event.prototype;
	window.CustomEvent = CustomEvent;
})();
class Main extends setCommonProperty{
	constructor(){
		super()
		/** globe variable **/
		if (!sessionStorage) {
			window.sessionStorage = new Object();
		}
		this.init()
	}

	/**
   	* 监控初始化配置, 以及启动的方法
   	*/
   	init() {
		try {
			// 启动监控
			this.recordPV();
			// this.recordResourceError(); //已经兼容 recordLoadPage
			this.recordLoadPage();
			this.recordBehavior({record: 1});
			this.recordJavaScriptError();
			this.recordHttpLog();
			// // 加载js压缩工具
			// utils.loadJs("//cdn.bootcss.com/lz-string/1.4.4/lz-string.js", function() {
			//   LZStringFlag = true
			//   // 加载录屏机制
			//   utils.loadJs("//cdn.jsdelivr.net/npm/rrweb@latest/dist/rrweb.min.js", function() {
			//     var stopFn = rrweb.record({
			//       emit(event) {
			//         // var newEvent = utils.compressJson(event);
			//         var newEventStr = JSON.stringify(event);
			//         if (LZStringFlag) {
			//           newEventStr = LZString.compressToBase64(newEventStr);
			//           var videosInfo = new VideosInfo(VIDEOS_EVENT, newEventStr);
			//           if (newEventStr.length) { // 如果数据过长，直接上传
			//             // videosInfo.uploadType = VIDEOS_EVENT
			//             // var logInfo = JSON.stringify(videosInfo)
			//             // utils.ajax("POST", "//localhost:8011/servers/upLog_long", newEventStr, function () {})
			//             var userId = "test_home"
			//             newEventStr = WEB_MONITOR_ID + "---" + VIDEOS_EVENT + "---" + utils.getCustomerKey() + "---" + userId + "$$$" + newEventStr
			//             var blob = new Blob([newEventStr], {type: 'text/plain'})
			//             var xmlHttp = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
			//             xmlHttp.open("post", "//localhost:8011/server/upLog_long", true);
			//             xmlHttp.setRequestHeader('Content-Type','text/plain');
			//             xmlHttp.send(blob);
			//           } else {
			//             // videosInfo.handleLogInfo(VIDEOS_EVENT, videosInfo);
			//           }
			//         }
			//       }
			//     })
			//   })
			// })
			
			/**
			 * 添加一个定时器，进行数据的上传
			 * 200毫秒钟进行一次URL是否变化的检测
			 * 8秒钟进行一次数据的检查并上传; PS: 这个时间有可能跟后台服务的并发量有着直接，谨慎设置
			 */
			var timeCount = 0;  // 200 * 40 	8秒进行一次数据上传
			var waitTimes = 0;   // 3次判断开关
			var typeList = [
				setCommonProperty.ELE_BEHAVIOR, 
				setCommonProperty.JS_ERROR, 
				setCommonProperty.HTTP_LOG, 
				setCommonProperty.SCREEN_SHOT, 
				setCommonProperty.CUSTOMER_PV, 
				setCommonProperty.LOAD_PAGE, 
				setCommonProperty.RESOURCE_LOAD, 
				setCommonProperty.CUSTOMIZE_BEHAVIOR, 
				setCommonProperty.VIDEOS_EVENT
			]
			setInterval(()=>{
				this.checkUrlChange();
				// 进行一次上传
				if (timeCount >= 40) {
					// 如果是本地的localhost, 就忽略，不进行上传
					// if (window.location.href.indexOf("localhost") != -1) return;
					var logInfo = "";
					for (var i = 0; i < typeList.length; i ++) {
						logInfo += (localStorage[typeList[i]] || "");
					}
					// 收集到日志的数量如果小于10，则不进行上传，减少后台服务短时间内的并发量。
					// 如果，经过3次判断还没有收集到10个日志，则进行上传
					// 风险：有可能会丢失掉用户最后一段时间的操作信息，如果，最后几步操作信息很重要，可以选择删除这段逻辑
					var logInfoCount = logInfo.split("$$$").length;
					if (logInfoCount < 10 && waitTimes < 2) {
						waitTimes ++;
						timeCount = 0;
						return;
					}
					waitTimes = 0;

					if(logInfo.length > 0){
						setCommonProperty.utils.ajax("POST", setCommonProperty.HTTP_UPLOAD_LOG_INFO, {logInfo: logInfo}, function () {
							for (var i = 0; i < typeList.length; i ++) {
								localStorage[typeList[i]] = "";
							}
						}, function () { // 如果失败了， 也需要清理掉本地缓存， 否则会积累太多
							for (var i = 0; i < typeList.length; i ++) {
								localStorage[typeList[i]] = "";
							}
						})
					} 
					timeCount = 0;
				}
				timeCount ++;
			}, 200);
		} catch (e) {
			console.error("监控代码异常，捕获", e);
		}
	}

	/**
   	* 用户访问记录监控
   	* @param project 项目详情
   	*/
   	checkUrlChange() {
		// 如果是单页应用， 只更改url
		var webLocation = window.location.href.split('?')[0].replace('#', '');
		// 如果url变化了， 就把更新的url记录为 defaultLocation, 重新设置pageKey
		if (setCommonProperty.defaultLocation != webLocation) {
			this.recordPV();
			setCommonProperty.defaultLocation = webLocation;
		}
	}

	/**
   	* 用户访问记录监控
   	* @param project 项目详情
   	*/
   	recordPV() {
    	setCommonProperty.utils.setPageKey();
    	var loadType = "load";
		if (setCommonProperty.resourcesObj) {
			if (setCommonProperty.resourcesObj[0] && setCommonProperty.resourcesObj[0].type === 'navigate') {
				loadType = "load";
			} else {
				loadType = "reload";
			}
		}
		// 判断是否是新用户  开始
		var customerKey = setCommonProperty.utils.getCustomerKey();
		var newStatus = "new";
		var customerKeyArr = customerKey ? customerKey.match(/\d{13}/g) : [];
		if (customerKeyArr && customerKeyArr.length > 0) {
			var tempTime = parseInt(customerKeyArr[0], 10);
			var currentTime = new Date().getTime();
			if (currentTime - tempTime > 1000) {
				newStatus = "new";
			} else {
				newStatus = "old";
			}
		}
		// 判断是否是新用户  结束
		var customerPv = new CustomerPV( loadType, 0, newStatus);
		// customerPv.handleLogInfo(setCommonProperty.CUSTOMER_PV, customerPv);
	}

	/**
   	* 用户加载页面信息监控
   	* @param project 项目详情
   	*/
   	recordLoadPage() {
		setCommonProperty.utils.addLoadEvent( ()=> {
			setTimeout( ()=> {
				if (setCommonProperty.resourcesObj) {
					var loadType = "load";
					if (setCommonProperty.resourcesObj[0] && setCommonProperty.resourcesObj[0].type === 'navigate') {
						loadType = "load";
					} else {
						loadType = "reload";
					}

					var t = setCommonProperty.timingObj;
					var loadPageInfo = new LoadPageInfo(t,loadType);
					// // 页面加载类型， 区分第一次load还是reload
					// loadPageInfo.loadType = loadType;

					// //【重要】页面加载完成的时间
					// //【原因】这几乎代表了用户等待页面可用的时间
					// loadPageInfo.loadPage = t.loadEventEnd - t.navigationStart;

					// //【重要】解析 DOM 树结构的时间
					// //【原因】反省下你的 DOM 树嵌套是不是太多了！
					// loadPageInfo.domReady = t.domComplete - t.responseEnd;

					// //【重要】重定向的时间
					// //【原因】拒绝重定向！比如，http://example.com/ 就不该写成 http://example.com
					// loadPageInfo.redirect = t.redirectEnd - t.redirectStart;

					// //【重要】DNS 查询时间
					// //【原因】DNS 预加载做了么？页面内是不是使用了太多不同的域名导致域名查询的时间太长？
					// // 可使用 HTML5 Prefetch 预查询 DNS ，见：[HTML5 prefetch](http://segmentfault.com/a/1190000000633364)
					// loadPageInfo.lookupDomain = t.domainLookupEnd - t.domainLookupStart;

					// //【重要】读取页面第一个字节的时间
					// //【原因】这可以理解为用户拿到你的资源占用的时间，加异地机房了么，加CDN 处理了么？加带宽了么？加 CPU 运算速度了么？
					// // TTFB 即 Time To First Byte 的意思
					// // 维基百科：https://en.wikipedia.org/wiki/Time_To_First_Byte
					// loadPageInfo.ttfb = t.responseStart - t.navigationStart;

					// //【重要】内容加载完成的时间
					// //【原因】页面内容经过 gzip 压缩了么，静态资源 css/js 等压缩了么？
					// loadPageInfo.request = t.responseEnd - t.requestStart;

					// //【重要】执行 onload 回调函数的时间
					// //【原因】是否太多不必要的操作都放到 onload 回调函数里执行了，考虑过延迟加载、按需加载的策略么？
					// loadPageInfo.loadEvent = t.loadEventEnd - t.loadEventStart;

					// // DNS 缓存时间
					// loadPageInfo.appcache = t.domainLookupStart - t.fetchStart;

					// // 卸载页面的时间
					// loadPageInfo.unloadEvent = t.unloadEventEnd - t.unloadEventStart;

					// // TCP 建立连接完成握手的时间
					// loadPageInfo.connect = t.connectEnd - t.connectStart;

					// loadPageInfo.handleLogInfo(setCommonProperty.LOAD_PAGE, loadPageInfo);
				}
				// 此方法有漏洞，暂时先注释掉
				this.performanceGetEntries();
			}, 1000);
		})
	}

	/**
   	* 监控页面静态资源加载报错
   	*/
   	recordResourceError() {
		// 当浏览器不支持 window.performance.getEntries 的时候，用下边这种方式
		window.addEventListener('error',function(e){
			var typeName = e.target.localName;
			var sourceUrl = "";
			if (typeName === "link") {
				sourceUrl = e.target.href;
			} else if (typeName === "script") {
				sourceUrl = e.target.src;
			}
			var resourceLoadInfo = new ResourceLoadInfo( sourceUrl, typeName, "0");
			// resourceLoadInfo.handleLogInfo(setCommonProperty.RESOURCE_LOAD, resourceLoadInfo);
		}, true);
	}

	/**
   	* 利用window.performance.getEntries来对比静态资源是否加载成功
   	*/
   	performanceGetEntries() {
		/**
		 * 判断静态资源是否加载成功, 将没有成功加载的资源文件作为js错误上报
		 */
		if (window.performance && typeof window.performance.getEntries === "function") {
			// 获取所有的静态资源文件加载列表
			var entries = window.performance.getEntries();
			var scriptArray = entries.filter(function (entry) {
				return entry.initiatorType === "script";
			});
			var linkArray = entries.filter(function (entry) {
				return entry.initiatorType === "link";
			});

			// 获取页面上所有的script标签, 并筛选出没有成功加载的静态资源
			var scripts = [];
			var scriptObjects = document.getElementsByTagName("script");
			for (var i = 0; i < scriptObjects.length; i ++) {
				if (scriptObjects[i].src) {
					scripts.push(scriptObjects[i].src);
				}
			}
			var errorScripts = scripts.filter(function (script) {
				var flag = true;
				for (var i = 0; i < scriptArray.length; i ++) {
					if (scriptArray[i].name === script) {
						flag = false;
						break;
					}
				}
				return flag;
			});

			// 获取所有的link标签
			var links = [];
			var linkObjects = document.getElementsByTagName("link");
			for (var i = 0; i < linkObjects.length; i ++) {
				if (linkObjects[i].href) {
					links.push(linkObjects[i].href);
				}
			}
			var errorLinks = links.filter(function (link) {
				var flag = true;
				for (var i = 0; i < linkArray.length; i ++) {
					if (linkArray[i].name === link) {
						flag = false;
						break;
					}
				}
				return flag;
			});
			for (var m = 0; m < errorScripts.length; m ++) {
				var resourceLoadInfo = new ResourceLoadInfo( errorScripts[m], "script", "0");
				// resourceLoadInfo.handleLogInfo(setCommonProperty.RESOURCE_LOAD, resourceLoadInfo);
			}
			for (var m = 0; m < errorLinks.length; m ++) {
				var resourceLoadInfo = new ResourceLoadInfo( errorLinks[m], "link", "0");
				// resourceLoadInfo.handleLogInfo(setCommonProperty.RESOURCE_LOAD, resourceLoadInfo);
			}
		}else{
			this.recordResourceError()
		}
	}

	/**
	 *  记录 页面js错误
	 */
	siftAndMakeUpMessage(infoType, origin_errorMsg, origin_url, origin_lineNumber, origin_columnNumber, origin_errorObj) {
		// 记录js错误前，检查一下url记录是否变化
		this.checkUrlChange();
		var errorMsg = origin_errorMsg ? origin_errorMsg : '';
		var errorObj = origin_errorObj ? origin_errorObj : '';
		var errorType = "";
		if (errorMsg) {
		  if (typeof errorObj === 'string') {
			errorType = errorObj.split(": ")[0].replace('"', "");
		  } else {
			var errorStackStr = JSON.stringify(errorObj)
			errorType = errorStackStr.split(": ")[0].replace('"', "");
		  }
		}
		var javaScriptErrorInfo = new JavaScriptErrorInfo( infoType, errorType + ": " + errorMsg, errorObj);
		// javaScriptErrorInfo.handleLogInfo(setCommonProperty.JS_ERROR, javaScriptErrorInfo);
	}

	/**
   	* 页面JS错误监控
   	*/
   	recordJavaScriptError() {
		// 重写console.error, 可以捕获更全面的报错信息
		var oldError = console.error;
		console.error = (tempErrorMsg)=> {
			var errorMsg = (arguments[0] && arguments[0].message) || tempErrorMsg;
			var lineNumber = 0;
			var columnNumber = 0;
			var errorObj = arguments[0] && arguments[0].stack;
			if (!errorObj) {
				this.siftAndMakeUpMessage("console_error", errorMsg, setCommonProperty.WEB_LOCATION, lineNumber, columnNumber, "CustomizeError: " + errorMsg);
			} else {
				this.siftAndMakeUpMessage("console_error", errorMsg, etCommonProperty.WEB_LOCATION, lineNumber, columnNumber, errorObj);
			}
			return oldError.apply(console, arguments);
		};
		// 重写 onerror 进行jsError的监听
		window.onerror = (errorMsg, url, lineNumber, columnNumber, errorObj) =>{
			setCommonProperty.jsMonitorStarted = true;
			var errorStack = errorObj ? errorObj.stack : null;
			this.siftAndMakeUpMessage("on_error", errorMsg, url, lineNumber, columnNumber, errorStack);
		};
		window.onunhandledrejection = function(e) {
			var errorMsg = "";
			var errorStack = "";
			if (typeof e.reason === "object") {
				errorMsg = e.reason.message;
				errorStack = e.reason.stack;
			} else {
				errorMsg = e.reason;
				errorStack = "";
			}
			siftAndMakeUpMessage("on_error", errorMsg, WEB_LOCATION, 0, 0, "UncaughtInPromiseError: " + errorStack);
		}
	}

	/**
   	* 页面接口请求监控
   	*/
   	recordHttpLog() {
		// 监听ajax的状态
		function ajaxEventTrigger(event) {
			var ajaxEvent = new CustomEvent(event, { detail: this });
			window.dispatchEvent(ajaxEvent);
		}
		var oldXHR = window.XMLHttpRequest;
		function newXHR() {
			var realXHR = new oldXHR();
			realXHR.addEventListener('abort', function () { ajaxEventTrigger.call(this, 'ajaxAbort'); }, false);
			realXHR.addEventListener('error', function () { ajaxEventTrigger.call(this, 'ajaxError'); }, false);
			realXHR.addEventListener('load', function () { ajaxEventTrigger.call(this, 'ajaxLoad'); }, false);
			realXHR.addEventListener('loadstart', function () { ajaxEventTrigger.call(this, 'ajaxLoadStart'); }, false);
			realXHR.addEventListener('progress', function () { ajaxEventTrigger.call(this, 'ajaxProgress'); }, false);
			realXHR.addEventListener('timeout', function () { ajaxEventTrigger.call(this, 'ajaxTimeout'); }, false);
			realXHR.addEventListener('loadend', function () { ajaxEventTrigger.call(this, 'ajaxLoadEnd'); }, false);
			realXHR.addEventListener('readystatechange', function() { ajaxEventTrigger.call(this, 'ajaxReadyStateChange'); }, false);
			// 此处的捕获的异常会连日志接口也一起捕获，如果日志上报接口异常了，就会导致死循环了。
			// realXHR.onerror = function () {
			//   siftAndMakeUpMessage("Uncaught FetchError: Failed to ajax", WEB_LOCATION, 0, 0, {});
			// }
			return realXHR;
		}
		function handleHttpResult(i, tempResponseText) {
			// 避免反复上传
			if (!timeRecordArray[i] || timeRecordArray[i].uploadFlag === true) {
				return;
			}
			// 根据返回的 记录长度
			var responseText = "";
			if (tempResponseText && responseText.length < 300) {
				try {
					responseText = tempResponseText ? JSON.stringify(setCommonProperty.utils.encryptObj(JSON.parse(tempResponseText))) : "";
				} catch (e) {
					responseText = "";
				}
			} else {
				responseText = "data is too long";
			}
			var simpleUrl = timeRecordArray[i].simpleUrl;
			var currentTime = new Date().getTime();
			var url = timeRecordArray[i].event.detail.responseURL;
			var status = timeRecordArray[i].event.detail.status;
			var statusText = timeRecordArray[i].event.detail.statusText;
			var loadTime = currentTime - timeRecordArray[i].timeStamp;
			// 避开上传 日志的接口
			if (!url || url.indexOf(setCommonProperty.HTTP_UPLOAD_LOG_API) != -1) return;
			var httpLogInfoStart = new HttpLogInfo(setCommonProperty.HTTP_LOG, simpleUrl, url, status, statusText, "发起请求", "", timeRecordArray[i].timeStamp, 0);
			// httpLogInfoStart.handleLogInfo(setCommonProperty.HTTP_LOG, httpLogInfoStart);
			var httpLogInfoEnd = new HttpLogInfo(setCommonProperty.HTTP_LOG, simpleUrl, url, status, statusText, "请求返回", responseText, currentTime, loadTime);
			// httpLogInfoEnd.handleLogInfo(setCommonProperty.HTTP_LOG, httpLogInfoEnd);
			// 当前请求成功后就，就将该对象的uploadFlag设置为true, 代表已经上传了
			timeRecordArray[i].uploadFlag = true;
		}

		// ajax 请求 和 返回的记录
		var timeRecordArray = [];
		window.XMLHttpRequest = newXHR;
		window.addEventListener('ajaxLoadStart', function(e) {
			var tempObj = {
				timeStamp: new Date().getTime(),
				event: e,
				simpleUrl: window.location.href.split('?')[0].replace('#', ''),
				uploadFlag: false,
			}
			timeRecordArray.push(tempObj)
		});
		window.addEventListener('ajaxLoadEnd', function() {
			for (var i = 0; i < timeRecordArray.length; i ++) {
				// uploadFlag == true 代表这个请求已经被上传过了
				if (timeRecordArray[i].uploadFlag === true) continue;
				if (timeRecordArray[i].event.detail.status > 0) {
					var rType = (timeRecordArray[i].event.detail.responseType + "").toLowerCase()
					if (rType === "blob") {
						(function(index) {
							var reader = new FileReader();
							reader.onload = function() {
								var responseText = reader.result;//内容就在这里
								handleHttpResult(index, responseText);
							}
							try {
								reader.readAsText(timeRecordArray[i].event.detail.response, 'utf-8');
							} catch (e) {
								handleHttpResult(index, timeRecordArray[i].event.detail.response + "");
							}
						})(i);
					} else {
						var responseText = timeRecordArray[i].event.detail.responseText;
						handleHttpResult(i, responseText);
					}
				}
			}
		});
	}

	/**
   	* 用户行为记录监控
   	* @param project 项目详情
   	*/
   	recordBehavior(project) {
		// 行为记录开关
		if (project && project.record && project.record == 1) {
			// 记录行为前，检查一下url记录是否变化
			this.checkUrlChange();
			// 记录用户点击元素的行为数据
			document.onclick = function (e) {
				var className = "";
				var placeholder = "";
				var inputValue = "";
				var tagName = e.target.tagName;
				var innerText = "";
				if (e.target.tagName != "svg" && e.target.tagName != "use") {
					className = e.target.className;
					placeholder = e.target.placeholder || "";
					inputValue = e.target.value || "";
					innerText = e.target.innerText ? e.target.innerText.replace(/\s*/g, "") : "";
					// 如果点击的内容过长，就截取上传 200字符
					if (innerText.length > 200) innerText = innerText.substring(0, 100) + "... ..." + innerText.substring(innerText.length - 99, innerText.length - 1);
					innerText = innerText.replace(/\s/g, '');
				}
				var behaviorInfo = new BehaviorInfo( "click", className, placeholder, inputValue, tagName, innerText);
				// behaviorInfo.handleLogInfo(setCommonProperty.ELE_BEHAVIOR, behaviorInfo);
			}
		}
	}

}
new Main()

//#########以下几条为暴露给用户的api 

class ZcMonitor {
	constructor(){
	}
	/**
	 * 埋点上传数据
	 * @param url 当前页面的url
	 * @param type 埋点类型
	 * @param index 埋点顺序
	 * @param description 其他信息描述
	*/
	wm_upload(url,type,index,description) {
		var createTime = new Date().toString();
		var logParams = {
			createTime: encodeURIComponent(createTime),
			happenTime: new Date().getTime(),
			uploadType: 'WM_UPLOAD',
			simpleUrl: encodeURIComponent(encodeURIComponent(url)),
			webMonitorId: setCommonProperty.WEB_MONITOR_ID,
			recordType: type,
			recordIndex: index,
			description: description
		};
		var http_api = setCommonProperty.HTTP_UPLOAD_RECORD_DATA;
		var recordDataXmlHttp = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP')
		recordDataXmlHttp.open('POST', http_api, true);
		recordDataXmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		recordDataXmlHttp.send('data=' + JSON.stringify([logParams]));
	}
	/**
	* 使用者传入的自定义信息
	*
	* @param userId
	* @param userName
	* @param userTpye
	*/
	wm_init_user (userId, userTag, secondUserParam) {
		if (!userId) console.warn('userId 初始化值为0(不推荐) 或者 未初始化');
		if (!secondUserParam) console.warn('secondParam 初始化值为0(不推荐) 或者 未初始化');
		// 如果用户传入了userTag值，重新定义WEB_MONITOR_ID
		if (userTag) {
			setCommonProperty.WEB_MONITOR_ID = userTag + "_webmonitor";
		}
		localStorage.wmUserInfo = JSON.stringify({
			userId: userId,
			userTag: userTag,
			secondUserParam: secondUserParam
		});
		return 1;
	}
	/**
	 * 使用者传入的自定义信息
	 *
	 * @param userId 用户唯一标识
	 * @param projectVersion 应用版本号
	 */
	wmInitUser(userId, projectVersion) {
		if (!userId) console.warn('userId(用户唯一标识) 初始化值为0(不推荐) 或者 未传值, 探针可能无法生效');
		if (!projectVersion) console.warn('projectVersion(应用版本号) 初始化值为0(不推荐) 或者 未传值, 探针可能无法生效');

		localStorage.wmUserInfo = JSON.stringify({
			userId: userId,
			projectVersion: projectVersion
		});
		return 1;
	}
	/**
	 * 使用者传入的自定义截屏指令, 由探针代码截图
	 * @param description  截屏描述
	 */
	wm_screen_shot(description) {
		setCommonProperty.utils.screenShot(document.body, description)
	}
	/**
	 * 使用者传入图片进行上传
	 * @param compressedDataURL 图片的base64编码字符串，description 图片描述
	 */
	wm_upload_picture(compressedDataURL, description, imgType) {
		var screenShotInfo = new ScreenShotInfo( description, compressedDataURL, imgType || "jpeg");
		// screenShotInfo.handleLogInfo(setCommonProperty.SCREEN_SHOT, screenShotInfo);
	}
	/**
	 * 使用者自行上传的行为日志
	 * @param userId 用户唯一标识
	 * @param behaviorType 行为类型
	 * @param behaviorResult 行为结果（成功、失败等）
	 * @param uploadType 日志类型（分类）
	 * @param description 行为描述
	 */
	wm_upload_extend_log (userId, behaviorType, behaviorResult, uploadType, description) {
		var extendBehaviorInfo = new ExtendBehaviorInfo(userId, behaviorType, behaviorResult, uploadType, description)
		extendBehaviorInfo.handleLogInfo(setCommonProperty.CUSTOMIZE_BEHAVIOR, extendBehaviorInfo);
	}
}
export default new ZcMonitor()




