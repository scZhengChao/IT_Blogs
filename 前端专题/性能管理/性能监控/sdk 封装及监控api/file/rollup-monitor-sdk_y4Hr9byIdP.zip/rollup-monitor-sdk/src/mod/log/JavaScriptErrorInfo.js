// JS错误日志，继承于日志基类MonitorBaseInfo
import setCommonProperty from '../setCommonProperty'
class JavaScriptErrorInfo extends setCommonProperty {
    constructor( infoType, errorMsg, errorStack){
        super()
        this.uploadType = setCommonProperty.JS_ERRO;
        this.infoType = infoType;
        this.pageKey = setCommonProperty.utils.getPageKey();  // 用于区分页面，所对应唯一的标识，每个新页面对应一个值
        this.deviceName = setCommonProperty.DEVICE_INFO.deviceName;
        this.os = setCommonProperty.DEVICE_INFO.os + (setCommonProperty.DEVICE_INFO.osVersion ? " " + setCommonProperty.DEVICE_INFO.osVersion : "");
        this.browserName = setCommonProperty.DEVICE_INFO.browserName;
        this.browserVersion = setCommonProperty.DEVICE_INFO.browserVersion;
        // TODO 位置信息, 待处理
        this.monitorIp = "";  // 用户的IP地址
        this.country = "china";  // 用户所在国家
        this.province = "";  // 用户所在省份
        this.city = "";  // 用户所在城市
        this.errorMessage = setCommonProperty.utils.b64EncodeUnicode(errorMsg)
        this.errorStack = setCommonProperty.utils.b64EncodeUnicode(errorStack);
        this.browserInfo = "";
        this.handleLogInfo(setCommonProperty.JS_ERROR,this)
    }
}
export default JavaScriptErrorInfo