 // 上传拓展日志信息的入口
 import setCommonProperty from '../setCommonProperty'
class VideosInfo extends setCommonProperty{
    constructor(uploadType, event){
        super()
        this.uploadType = uploadType;
        this.event = event;
    }
}
  export default VideosInfo