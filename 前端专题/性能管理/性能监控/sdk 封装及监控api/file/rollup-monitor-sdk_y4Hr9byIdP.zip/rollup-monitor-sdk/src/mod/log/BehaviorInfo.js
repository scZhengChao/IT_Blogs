// 用户行为日志，继承于日志基类MonitorBaseInfo
import setCommonProperty from '../setCommonProperty'
class BehaviorInfo extends setCommonProperty{
    constructor(behaviorType, className, placeholder, inputValue, tagName, innerText){
        super()
        this.uploadType = setCommonProperty.ELE_BEHAVIOR;
        this.behaviorType = behaviorType;
        this.className = setCommonProperty.utils.b64EncodeUnicode(className);
        this.placeholder = setCommonProperty.utils.b64EncodeUnicode(placeholder);
        this.inputValue = setCommonProperty.utils.b64EncodeUnicode(inputValue);
        this.tagName = tagName;
        this.innerText = setCommonProperty.utils.b64EncodeUnicode(encodeURIComponent(innerText));
        this.handleLogInfo(this.uploadType,this)
    }
}
export default BehaviorInfo