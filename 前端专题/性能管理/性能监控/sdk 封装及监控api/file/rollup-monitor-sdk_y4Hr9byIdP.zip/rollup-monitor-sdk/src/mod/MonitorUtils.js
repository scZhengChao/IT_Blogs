 /**
   * 监控代码需要的工具类
   * @constructor
   */
class MonitorUtils{
    constructor(options){

    }
    getUuid(){
        var timeStamp = new Date().getTime()
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
          var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
          return v.toString(16);
        }) + "-" + timeStamp;
    };
    /**
     * 获取用户的唯一标识
     */
    getCustomerKey(MAIN_DOMAIN){
        var customerKey = this.getUuid();
        var monitorCustomerKey = this.getCookie("monitorCustomerKey");
        if (!monitorCustomerKey) {
          var extraTime = 60 * 30 * 24 * 3600 * 1000 // cookie 30天后过期时间
          var exp = new Date()
          exp.setTime(exp.getTime() + extraTime)
          if (MAIN_DOMAIN) {
            document.cookie = "monitorCustomerKey=" + customerKey + ";Path=/;domain=" + MAIN_DOMAIN + ";expires=" + exp.toGMTString()
          } else {
            document.cookie = "monitorCustomerKey=" + customerKey + ";Path=/;expires=" + exp.toGMTString()
          }
          monitorCustomerKey = customerKey
        }
        return monitorCustomerKey;
    };
    /**
     * 获取cookie
     */
    getCookie(name) {
        var arr
        var reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)")
        if (document.cookie.match(reg)) {
          arr = document.cookie.match(reg)
          return unescape(arr[2])
        }
        return ""
    }
    /**
     * 获取页面的唯一标识
     */
    getPageKey(){
        var pageKey = this.getUuid();
        var reg = /^[0-9a-z]{8}(-[0-9a-z]{4}){3}-[0-9a-z]{12}-\d{13}$/
        if (!localStorage.monitorPageKey) {
          localStorage.monitorPageKey = pageKey;
        } else if (!reg.test(localStorage.monitorPageKey)) {
          localStorage.monitorPageKey = pageKey;
        }
        return localStorage.monitorPageKey;
    };
     /**
     * 设置页面的唯一标识
     */
    setPageKey(){
        localStorage.monitorPageKey = this.getUuid();
    };
    /**
     * 重写页面的onload事件
     */
    addLoadEvent(func){
        var oldOnload = window.onload; //把现在有window.onload事件处理函数的值存入变量oldonload。
        if(typeof window.onload != 'function'){ //如果这个处理函数还没有绑定任何函数，就像平时那样把新函数添加给它
          window.onload = func;
        } else { //如果在这个处理函数上已经绑定了一些函数。就把新函数追加到现有指令的末尾
          window.onload = function(){
            oldOnload();
            func();
          }
        }
    }
    /**
     * 封装简易的ajax请求
     * @param method  请求类型(大写)  GET/POST
     * @param url     请求URL
     * @param param   请求参数
     * @param successCallback  成功回调方法
     * @param failCallback   失败回调方法
     */
    ajax(method, url, param, successCallback, failCallback) {
        var xmlHttp = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        xmlHttp.open(method, url, true);
        xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xmlHttp.onreadystatechange = function () {
          if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            var res = JSON.parse(xmlHttp.responseText);
            typeof successCallback == 'function' && successCallback(res);
          } else {
            typeof failCallback == 'function' && failCallback();
          }
        };
        xmlHttp.send("data=" + JSON.stringify(param));
    }
    /**
     * js处理截图
     */
    screenShot(cntElem, description){
        var shareContent = cntElem;//需要截图的包裹的（原生的）DOM 对象
        var width = shareContent.offsetWidth; //获取dom 宽度
        var height = shareContent.offsetHeight; //获取dom 高度
        var canvas = document.createElement("canvas"); //创建一个canvas节点
        var scale = 0.3; //定义任意放大倍数 支持小数
        canvas.style.display = "none";
        canvas.width = width * scale; //定义canvas 宽度 * 缩放
        canvas.height = height * scale; //定义canvas高度 *缩放
        canvas.getContext("2d").scale(scale, scale); //获取context,设置scale
        var opts = {
          scale: scale, // 添加的scale 参数
          canvas: canvas, //自定义 canvas
          logging: false, //日志开关，便于查看html2canvas的内部执行流程
          width: width, //dom 原始宽度
          height: height,
          useCORS: true // 【重要】开启跨域配置
        };
        window.html2canvas && window.html2canvas(cntElem, opts).then((canvas)=>{
          var dataURL = canvas.toDataURL("image/webp");
          var tempCompress = dataURL.replace("data:image/webp;base64,", "");
          var compressedDataURL = this.b64EncodeUnicode(tempCompress);
          var screenShotInfo = new ScreenShotInfo(SCREEN_SHOT, description, compressedDataURL)
          screenShotInfo.handleLogInfo(SCREEN_SHOT, screenShotInfo);
        });
    }
    // 深拷贝方法. 注意: 如果对象里边包含function, 则对function的拷贝依然是浅拷贝
    encryptObj(o){
        if (o instanceof Array) {
          var n = []
          for (var i = 0; i < o.length; ++i) {
            n[i] = this.encryptObj(o[i])
          }
          return n
        } else if (o instanceof Object) {
          var n = {}
          for (var i in o) {
            n[i] = this.encryptObj(o[i])
          }
          return n
        }
        o = o + ""
        if (o.length > 8) {
          o = o.substring(0, 4) + "****" + o.substring(o.length - 3, o.length)
        }
        return o
    }
    // 压缩JSON字符串, 对key进行压缩
    // window.keyArray = localStorage.keyArray ? JSON.parse(localStorage.keyArray) : []
    // window.keyCountArray = window.keyCountArray ? JSON.parse(localStorage.keyArray) : []
    compressJson(o) {
        if (o instanceof Array) {
          var n = []
          for (var i = 0; i < o.length; ++i) {
            n[i] = this.compressJson(o[i])
          }
          return n
        } else if (o instanceof Object) {
          var n = {}
          for (var i in o) {
            // if (window.keyArray.indexOf(i) == -1) {
            //   window.keyArray.push(i)
            // }
  
            // if (window.keyCountArray.length) {
            //   for (var m = 0; m < window.keyCountArray.length; m ++) {
            //     if (window.keyCountArray[m][i]) {
            //       window.keyCountArray[m][i] = window.keyCountArray[m][i] + 1
            //     } else {
            //       window.keyCountArray[m][i] = 1
            //     }
            //   }
            // } else {
            //   var obj = {}
            //   obj[i] = 1
            //   window.keyCountArray.push(obj)
            // }
            if (i == "_cssText") {
              o[i]= o[i].replace(/ {/g, "{").replace(/; /g, ";").replace(/: /g, ":").replace(/, /g, ",").replace(/{ /g, "{")
              for (var key in JSON_CSS_KEY) {
                var cssAttr = JSON_CSS_KEY[key]
                var cssReg = new RegExp(key, "g");
                o[i]= o[i].replace(cssReg, cssAttr)
              }
            }
  
            if (JSON_KEY[i]) {
              n[JSON_KEY[i]] = this.compressJson(o[i])
              delete n[i]
            } else {
              n[i] = this.compressJson(o[i])
            }
          }
          return n
        }
        return o
    }
    Compress(strNormalString) {
        var strCompressedString = "";
    
        var ht = new Array();
        for(i = 0; i < 128; i++) {
            ht[i] = i;
        }
    
        var used = 128;
        var intLeftOver = 0;
        var intOutputCode = 0;
        var pcode = 0;
        var ccode = 0;
        var k = 0;
    
        for(var i=0; i<strNormalString.length; i++) {
            ccode = strNormalString.charCodeAt(i);
            k = (pcode << 8) | ccode;
            if(ht[k] != null) {
                pcode = ht[k];
            } else {
                intLeftOver += 12;
                intOutputCode <<= 12;
                intOutputCode |= pcode;
                pcode = ccode;
                if(intLeftOver >= 16) {
                    strCompressedString += String.fromCharCode( intOutputCode >> ( intLeftOver - 16 ) );
                    intOutputCode &= (Math.pow(2, (intLeftOver - 16)) - 1);
                    intLeftOver -= 16;
                }
                if(used < 4096) {
                    used ++;
                    ht[k] = used - 1;
                }
            }
        }
    
        if(pcode != 0) {
            intLeftOver += 12;
            intOutputCode <<= 12;
            intOutputCode |= pcode;
        }
    
        if(intLeftOver >= 16) {
            strCompressedString += String.fromCharCode( intOutputCode >> ( intLeftOver - 16 ) );
            intOutputCode &= (Math.pow(2,(intLeftOver - 16)) - 1);
            intLeftOver -= 16;
        }
    
        if( intLeftOver > 0) {
            intOutputCode <<= (16 - intLeftOver);
            strCompressedString += String.fromCharCode( intOutputCode );
        }
    
        return strCompressedString;
    }
    Decompress(strCompressedString) {
        var strNormalString = "";
        var ht = new Array();

        for(i = 0; i < 128; i++) {
            ht[i] = String.fromCharCode(i);
        }

        var used = 128;
        var intLeftOver = 0;
        var intOutputCode = 0;
        var ccode = 0;
        var pcode = 0;
        var key = 0;

        for(var i=0; i<strCompressedString.length; i++) {
            intLeftOver += 16;
            intOutputCode <<= 16;
            intOutputCode |= strCompressedString.charCodeAt(i);

            while(1) {
                if(intLeftOver >= 12) {
                    ccode = intOutputCode >> (intLeftOver - 12);
                    if( typeof( key = ht[ccode] ) != "undefined" ) {
                        strNormalString += key;
                        if(used > 128) {
                            ht[ht.length] = ht[pcode] + key.substr(0, 1);
                        }
                        pcode = ccode;
                    } else {
                        key = ht[pcode] + ht[pcode].substr(0, 1);
                        strNormalString += key;
                        ht[ht.length] = ht[pcode] + key.substr(0, 1);
                        pcode = ht.length - 1;
                    }

                    used ++;
                    intLeftOver -= 12;
                    intOutputCode &= (Math.pow(2,intLeftOver) - 1);
                } else {
                    break;
                }
            }
        }
        return strNormalString;
    }
    // 获取设备信息
    getDevice() {
        var device = {};
        var ua = navigator.userAgent;
        var android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
        var ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
        var ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
        var iphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/);
        var mobileInfo = ua.match(/Android\s[\S\s]+Build\//);
        device.ios = device.android = device.iphone = device.ipad = device.androidChrome = false;
        device.isWeixin = /MicroMessenger/i.test(ua);
        device.os = "web";
        device.deviceName = "PC";
        // Android
        if (android) {
          device.os = 'android';
          device.osVersion = android[2];
          device.android = true;
          device.androidChrome = ua.toLowerCase().indexOf('chrome') >= 0;
        }
        if (ipad || iphone || ipod) {
          device.os = 'ios';
          device.ios = true;
        }
        // iOS
        if (iphone && !ipod) {
          device.osVersion = iphone[2].replace(/_/g, '.');
          device.iphone = true;
        }
        if (ipad) {
          device.osVersion = ipad[2].replace(/_/g, '.');
          device.ipad = true;
        }
        if (ipod) {
          device.osVersion = ipod[3] ? ipod[3].replace(/_/g, '.') : null;
          device.iphone = true;
        }
        // iOS 8+ changed UA
        if (device.ios && device.osVersion && ua.indexOf('Version/') >= 0) {
          if (device.osVersion.split('.')[0] === '10') {
            device.osVersion = ua.toLowerCase().split('version/')[1].split(' ')[0];
          }
        }
  
        // 如果是ios, deviceName 就设置为iphone，根据分辨率区别型号
        if (device.iphone) {
          device.deviceName = "iphone";
          var screenWidth = window.screen.width;
          var screenHeight = window.screen.height;
          if (screenWidth === 320 && screenHeight === 480) {
            device.deviceName = "iphone 4";
          } else if (screenWidth === 320 && screenHeight === 568) {
            device.deviceName = "iphone 5/SE";
          } else if (screenWidth === 375 && screenHeight === 667) {
            device.deviceName = "iphone 6/7/8";
          } else if (screenWidth === 414 && screenHeight === 736) {
            device.deviceName = "iphone 6/7/8 Plus";
          } else if (screenWidth === 375 && screenHeight === 812) {
            device.deviceName = "iphone X/S/Max";
          }
        } else if (device.ipad) {
          device.deviceName = "ipad";
        } else if (mobileInfo) {
          var info = mobileInfo[0];
          var deviceName = info.split(';')[1].replace(/Build\//g, "");
          device.deviceName = deviceName.replace(/(^\s*)|(\s*$)/g, "");
        }
        // 浏览器模式, 获取浏览器信息
        // TODO 需要补充更多的浏览器类型进来
        if (ua.indexOf("Mobile") == -1) {
          var agent = navigator.userAgent.toLowerCase() ;
          var regStr_ie = /msie [\d.]+;/gi ;
          var regStr_ff = /firefox\/[\d.]+/gi
          var regStr_chrome = /chrome\/[\d.]+/gi ;
          var regStr_saf = /safari\/[\d.]+/gi ;
  
          device.browserName = '未知';
          //IE
          if(agent.indexOf("msie") > 0) {
            var browserInfo = agent.match(regStr_ie)[0];
            device.browserName = browserInfo.split('/')[0];
            device.browserVersion = browserInfo.split('/')[1];
          }
          //firefox
          if(agent.indexOf("firefox") > 0) {
            var browserInfo = agent.match(regStr_ff)[0];
            device.browserName = browserInfo.split('/')[0];
            device.browserVersion = browserInfo.split('/')[1];
          }
          //Safari
          if(agent.indexOf("safari") > 0 && agent.indexOf("chrome") < 0) {
            var browserInfo = agent.match(regStr_saf)[0];
            device.browserName = browserInfo.split('/')[0];
            device.browserVersion = browserInfo.split('/')[1];
          }
          //Chrome
          if(agent.indexOf("chrome") > 0) {
            var browserInfo = agent.match(regStr_chrome)[0];
            device.browserName = browserInfo.split('/')[0];
            device.browserVersion = browserInfo.split('/')[1];
          }
        }
        // Webview
        device.webView = (iphone || ipad || ipod) && ua.match(/.*AppleWebKit(?!.*Safari)/i);
  
        // Export object
        return device;
    }
    // 异步加载 非阻塞式 script  在所有 script标签之前
    loadJs(url, callback) {
        var script = document.createElement('script');
        script.async = 1;
        script.src = url;
        script.onload = callback;
        var dom = document.getElementsByTagName('script')[0];
        dom.parentNode.insertBefore(script, dom);
        return dom;
    }
    // 转码
    b64EncodeUnicode(str){
        try {
          return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
            return String.fromCharCode("0x" + p1);
          }));
        } catch (e) {
          return str;
        }
    }
    // 字符串转换成二进制流
    char2buf(str) {
        var out = new ArrayBuffer(str.length*2);
        var u16a= new Uint16Array(out);
        var strs = str.split("");
        for(var i =0 ; i<strs.length;i++){
            u16a[i]=strs[i].charCodeAt();
        }
        return out;
    }
}
export default MonitorUtils
