  // JS错误截图，继承于日志基类MonitorBaseInfo
  import setCommonProperty from '../setCommonProperty'
class ScreenShotInfo extends setCommonProperty{
    constructor( des, screenInfo, imgType) {
        super()
        this.uploadType = setCommonProperty.SCREEN_SHOT;
        this.description = setCommonProperty.utils.b64EncodeUnicode(des);
        this.screenInfo = screenInfo;
        this.imgType = imgType || "jpeg";
        this.handleLogInfo(setCommonProperty.SCREEN_SHOT,this)
    }
  
}
export default ScreenShotInfo