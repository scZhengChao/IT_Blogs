 // 用户访问行为日志(PV)
 import setCommonProperty from '../setCommonProperty'
class CustomerPV extends setCommonProperty{
    constructor(loadType, loadTime, newStatus){
        super()
        this.uploadType = setCommonProperty.CUSTOMER_PV;
        this.projectVersion = setCommonProperty.utils.b64EncodeUnicode(setCommonProperty.USER_INFO.projectVersion || ""); // 版本号， 用来区分监控应用的版本，更有利于排查问题
        this.pageKey = setCommonProperty.utils.getPageKey();  // 用于区分页面，所对应唯一的标识，每个新页面对应一个值
        this.deviceName = setCommonProperty.DEVICE_INFO.deviceName;
        this.os = setCommonProperty.DEVICE_INFO.os + (setCommonProperty.DEVICE_INFO.osVersion ? " " + setCommonProperty.DEVICE_INFO.osVersion : "");
        this.browserName = setCommonProperty.DEVICE_INFO.browserName;
        this.browserVersion = setCommonProperty.DEVICE_INFO.browserVersion;
        // TODO 位置信息, 待处理
        this.monitorIp = "";  // 用户的IP地址
        this.country = "china";  // 用户所在国家
        this.province = "";  // 用户所在省份
        this.city = "";  // 用户所在城市
        this.loadType = loadType;  // 用以区分首次加载
        this.loadTime = loadTime; // 加载时间
        this.newStatus = newStatus; // 是否为新用户
        this.handleLogInfo(this.uploadType,this)
    }
}
export default CustomerPV