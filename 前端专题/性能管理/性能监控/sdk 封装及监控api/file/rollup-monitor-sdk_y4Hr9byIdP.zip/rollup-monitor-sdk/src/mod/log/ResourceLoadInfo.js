// 页面静态资源加载错误统计，继承于日志基类MonitorBaseInfo
import setCommonProperty from '../setCommonProperty'
class ResourceLoadInfo extends  setCommonProperty{
    constructor(url, elementType, status){
        super()
        this.uploadType = setCommonProperty.RESOURCE_LOAD;
        this.elementType = elementType;
        this.sourceUrl = setCommonProperty.utils.b64EncodeUnicode(encodeURIComponent(url));
        this.status = status;  // 资源加载状态： 0/失败、1/成功
        this.handleLogInfo(setCommonProperty.RESOURCE_LOAD,this)
    }
   
}
export default ResourceLoadInfo