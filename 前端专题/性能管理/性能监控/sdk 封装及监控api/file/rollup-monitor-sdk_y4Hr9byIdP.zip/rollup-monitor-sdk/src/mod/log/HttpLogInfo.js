 // 接口请求日志，继承于日志基类MonitorBaseInfo
 import setCommonProperty from '../setCommonProperty'
 class HttpLogInfo extends setCommonProperty{
     constructor( simpleUrl, url, status, statusText, statusResult, responseText, currentTime, loadTime){
        super()
        this.uploadType = setCommonProperty.HTTP_LOG;  // 上传类型
        this.simpleUrl = simpleUrl;
        this.httpUrl = setCommonProperty.utils.b64EncodeUnicode(encodeURIComponent(url)); // 请求地址
        this.status = status; // 接口状态
        this.statusText = statusText; // 状态描述
        this.statusResult = statusResult; // 区分发起和返回状态
        this.requestText = ""; // 请求参数的JSON字符串
        this.responseText = setCommonProperty.utils.b64EncodeUnicode(responseText); // 返回的结果JSON字符串
        this.happenTime = currentTime;  // 客户端发送时间
        this.loadTime = loadTime; // 接口请求耗时
        this.handleLogInfo(setCommonProperty.HTTP_LOG,this)
    }
}
export default HttpLogInfo