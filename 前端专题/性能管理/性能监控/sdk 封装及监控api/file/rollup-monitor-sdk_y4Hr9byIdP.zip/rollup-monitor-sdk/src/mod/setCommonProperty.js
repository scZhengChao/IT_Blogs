/**
* 日志对象的key都跟monitorKeys的缩短key值一一对应，以达到减少日志长度的目的
*/
// 设置日志对象类的通用属性
import MonitorUtils from './MonitorUtils' // 工具类
class setCommonProperty{
    constructor(){
		// 实列属性 将作为json 日志 输出
        this.happenTime = new Date().getTime(); // 日志发生时间
        this.webMonitorId = setCommonProperty.WEB_MONITOR_ID;     // 用于区分应用的唯一标识（一个项目对应一个）
        this.simpleUrl =  window.location.href.split('?')[0].replace('#', ''); // 页面的url
        this.completeUrl =  setCommonProperty.utils.b64EncodeUnicode(encodeURIComponent(window.location.href)); // 页面的完整url
        this.customerKey = setCommonProperty.utils.getCustomerKey(); // 用于区分用户，所对应唯一的标识，清理本地数据后失效，
        // 用户自定义信息， 由开发者主动传入， 便于对线上问题进行准确定位
        var wmUserInfo = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : "";
        this.userId = setCommonProperty.utils.b64EncodeUnicode(wmUserInfo.userId || "");
        this.firstUserParam = setCommonProperty.utils.b64EncodeUnicode(wmUserInfo.firstUserParam || "");
        this.secondUserParam = setCommonProperty.utils.b64EncodeUnicode(wmUserInfo.secondUserParam || "");
    }
    // 日志基类, 用于其他日志的继承
    handleLogInfo(type,logInfo) {
        var tempString = localStorage[type] ? localStorage[type] : "";
        localStorage[type] = tempString + JSON.stringify(logInfo) + '$$$';
    };
    
}
// 以下类属性, 见作为全局公共属性 挂在setCommonProperty上

// 用fetch方式请求接口时，暂存接口url
setCommonProperty.fetchHttpUrl = null
// 自动上传日志记录的定时器
setCommonProperty.webMonitorUploadTimer = null
// 暂存本地用于保存日志信息的数组
setCommonProperty.uploadMessageArray = null
// onerror 错误监控启动状态
setCommonProperty.jsMonitorStarted = false
// 上传日志的开关，如果为false，则不再上传
setCommonProperty.uploadRemoteServer = true
// 保存图片对应的描述，同一个描述只保存一次
setCommonProperty.screenShotDescriptions = []
// 屏幕截图字符串
setCommonProperty.tempScreenShot = ""
// 获取当前url
setCommonProperty.defaultLocation = window.location.href.split('?')[0].replace('#', '')
// 页面加载对象属性
setCommonProperty.timingObj = performance && performance.timing
// 获取页面加载的具体属性
setCommonProperty.resourcesObj = (function() {
	if (performance && typeof performance.getEntries === 'function') {
		return performance.getEntries();
	}
	return null;
})();
/** 常量 **/
// 所属项目ID, 用于替换成相应项目的UUID，生成监控代码的时候搜索替换
setCommonProperty.WEB_MONITOR_ID = sessionStorage.CUSTOMER_WEB_MONITOR_ID || "jeffery_webmonitor"

// 判断是http或是https的项目
setCommonProperty.WEB_HTTP_TYPE = window.location.href.indexOf('https') === -1 ? 'http://' : 'https://'

// 获取当前页面的URL
setCommonProperty.WEB_LOCATION = window.location.href

// 本地IP, 用于区分本地开发环境
setCommonProperty.WEB_LOCAL_IP = 'localhost'

// 应用的主域名, 用于主域名下共享customerKey
setCommonProperty.MAIN_DOMAIN = '&&&webfunny.cn&&&'

// 监控平台地址
setCommonProperty.WEB_MONITOR_IP = '&&&www.webfunny.cn&&&'

// 上传数据的uri, 区分了本地和生产环境
setCommonProperty.HTTP_UPLOAD_URI =  setCommonProperty.WEB_LOCATION.indexOf(setCommonProperty.WEB_LOCAL_IP) == -1 ? setCommonProperty.WEB_HTTP_TYPE + setCommonProperty.WEB_MONITOR_IP : setCommonProperty.WEB_HTTP_TYPE + setCommonProperty.WEB_LOCAL_IP + ':3000'

// 上传数据的接口API
setCommonProperty.HTTP_UPLOAD_LOG_API = '/server/upLog' // '/api/v1/upLog'

// 上传数据时忽略的uri, 需要过滤掉监控平台上传接口
setCommonProperty.WEB_MONITOR_IGNORE_URL = setCommonProperty.HTTP_UPLOAD_URI + setCommonProperty.HTTP_UPLOAD_LOG_API

// 上传数据的接口
setCommonProperty.HTTP_UPLOAD_LOG_INFO =setCommonProperty.HTTP_UPLOAD_URI + setCommonProperty.HTTP_UPLOAD_LOG_API

// 获取当前项目的参数信息的接口
setCommonProperty.HTTP_PROJECT_INFO = setCommonProperty.HTTP_UPLOAD_URI + '/server/project/getProject'

// 上传埋点数据接口
setCommonProperty.HTTP_UPLOAD_RECORD_DATA = setCommonProperty.HTTP_UPLOAD_URI + ''

// 用户访问日志类型
setCommonProperty.CUSTOMER_PV = 'CUSTOMER_PV'

// 用户加载页面信息类型
setCommonProperty.LOAD_PAGE = 'LOAD_PAGE'

// 接口日志类型
setCommonProperty.HTTP_LOG = 'HTTP_LOG'

// 接口错误日志类型
setCommonProperty.HTTP_ERROR = 'HTTP_ERROR'

// js报错日志类型
setCommonProperty.JS_ERROR = 'JS_ERROR'

// 截屏类型
setCommonProperty.SCREEN_SHOT = 'SCREEN_SHOT'

// 用户的行为类型
setCommonProperty.ELE_BEHAVIOR = 'ELE_BEHAVIOR'

// 静态资源类型
setCommonProperty.RESOURCE_LOAD = 'RESOURCE_LOAD'

// 用户自定义行为类型
setCommonProperty.CUSTOMIZE_BEHAVIOR = 'CUSTOMIZE_BEHAVIOR'

// 用户录屏事件类型
setCommonProperty.VIDEOS_EVENT = 'VIDEOS_EVENT'

// 浏览器信息
setCommonProperty.BROWSER_INFO = window.navigator.userAgent

// 工具类示例化
setCommonProperty.utils = new MonitorUtils()

// 设备信息
setCommonProperty.DEVICE_INFO = setCommonProperty.utils.getDevice()

// 监控代码空构造函数
setCommonProperty.WebMonitor = {}

// 获取用户自定义信息
setCommonProperty.USER_INFO = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : {}

// 录屏JSON字符简化
setCommonProperty.JSON_KEY = {"type":"≠","childNodes":"ā","name":"á","id":"ǎ","tagName":"à","attributes":"ē","style":"é","textContent":"ě","isStyle":"è","isSVG":"ī","content":"í","href":"ǐ","src":"ì","class":"ō","tabindex":"ó","aria-label":"ǒ","viewBox":"ò","focusable":"ū","data-icon":"ú","width":"ǔ","height":"ù","fill":"ǖ","aria-hidden":"ǘ","stroke":"ǚ","stroke-width":"ǜ","paint-order":"ü","stroke-opacity":"ê","stroke-dasharray":"ɑ","stroke-linecap":"?","stroke-linejoin":"ń","stroke-miterlimit":"ň","clip-path":"Γ","alignment-baseline":"Δ","fill-opacity":"Θ","transform":"Ξ","text-anchor":"Π","offset":"Σ","stop-color":"Υ","stop-opacity":"Φ"}
setCommonProperty.JSON_CSS_KEY = {"background":"≠","background-attachment":"ā","background-color":"á","background-image":"ǎ","background-position":"à","background-repeat":"ē","background-clip":"é","background-origin":"ě","background-size":"è","border":"Г","border-bottom":"η","color":"┯","style":"Υ","width":"б","border-color":"ū","border-left":"ǚ","border-right":"ň","border-style":"Δ","border-top":"З","border-width":"Ω","outline":"α","outline-color":"β","outline-style":"γ","outline-width":"δ","left-radius":"Ж","right-radius":"И","border-image":"ω","outset":"μ","repeat":"ξ","repeated":"π","rounded":"ρ","stretched":"σ","slice":"υ","source":"ψ","border-radius":"Б","radius":"Д","box-decoration":"Й","break":"К","box-shadow":"Л","overflow-x":"Ф","overflow-y":"У","overflow-style":"Ц","rotation":"Ч","rotation-point":"Щ","opacity":"Ъ","height":"Ы","max-height":"Э","max-width":"Ю","min-height":"Я","min-width":"а","font":"в","font-family":"г","font-size":"ж","adjust":"з","aspect":"и","font-stretch":"й","font-style":"к","font-variant":"л","font-weight":"ф","content":"ц","before":"ч","after":"ш","counter-increment":"щ","counter-reset":"ъ","quotes":"ы","list-style":"+","image":"－","position":"|","type":"┌","margin":"┍","margin-bottom":"┎","margin-left":"┏","margin-right":"┐","margin-top":"┑","padding":"┒","padding-bottom":"┓","padding-left":"—","padding-right":"┄","padding-top":"┈","bottom":"├","clear":"┝","clip":"┞","cursor":"┟","display":"┠","float":"┡","left":"┢","overflow":"┣","right":"┆","top":"┊","vertical-align":"┬","visibility":"┭","z-index":"┮","direction":"┰","letter-spacing":"┱","line-height":"┲","text-align":"6","text-decoration":"┼","text-indent":"┽","text-shadow":"10","text-transform":"┿","unicode-bidi":"╀","white-space":"╂","word-spacing":"╁","hanging-punctuation":"╃","punctuation-trim":"1","last":"3","text-emphasis":"4","text-justify":"5","justify":"7","text-outline":"8","text-overflow":"9","text-wrap":"11","word-break":"12","word-wrap":"13"}

// LZString 加载标识
setCommonProperty.LZStringFlag = false;
export default setCommonProperty