
module.exports = {
    build:{
        plugins: [
           
        ]
    },
    dev:{
        plugins: [
           
        ]
    }
}