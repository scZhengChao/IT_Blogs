#####  ZcMonitor  暴露对外的全局对象  供用户使用的api
#####  MonitorUtils   工具函数对象
#####  setCommonProperty   公共日志部分  和 公共的属性 挂载
#####  Main    主程     唯一一个 程序启动入口
#####  log     各个日志  
#####  npm run dev/build   监测更改自动刷新/build
#####  完整版 256kb  兼容fetch 95kb   精简版 67kb
#####  对比原版  188kb   兼容fetch 26kb   相差 69kb  当然他没有用babel 我是用了babel
#####  经测验 兼容ie9 
#### 缺点
1.    包过大 想办法减少 体量 删除没用的
*